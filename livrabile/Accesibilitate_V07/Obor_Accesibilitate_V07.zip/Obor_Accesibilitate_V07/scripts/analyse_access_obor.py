import os,sys,json,math,heapq,collections,time
sys.path.insert(0,'/tmp/obor-ifc')
import numpy as np,shapely
from shapely.geometry import shape,Point,LineString,Polygon,mapping,box
from shapely.ops import unary_union
from shapely.affinity import translate
from scipy.spatial import cKDTree
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));O=ROOT;os.makedirs(O,exist_ok=True)
D=json.load(open(ROOT+'/inputs/osm_projected.json'));geom=json.load(open(ROOT+'/inputs/osm_geometries.json'));R=json.load(open(ROOT+'/inputs/Spatii_verzi_individuale.json'));base=json.load(open(ROOT+'/inputs/Geometrii_bilant.json'));study=shape(base['study']);site=shape(base['site']);built=shape(base['built']);tx,ty=json.load(open(ROOT+'/inputs/osm_registration.json'))['translation_osm_to_cad'];roi=study.buffer(750)
nodes=D['nodes'];xy={k:np.array(v['xy'])+[tx,ty] for k,v in nodes.items()};ways=D['ways']
rail=[];walls=[];waters=[];restricted=[];gates=[];crossings=[]
for k,n in nodes.items():
 t=n.get('tags',{})
 if t.get('barrier') in ['gate','lift_gate','swing_gate','entrance','kissing_gate','bollard','cycle_barrier'] and t.get('access') not in ['no','private']:gates.append(Point(xy[k]))
 if t.get('railway') in ['crossing','level_crossing']:crossings.append(Point(xy[k]))
for k,w in ways.items():
 t=w.get('tags',{});coords=[xy[n] for n in w['nodes'] if n in xy]
 if len(coords)<2:continue
 ls=LineString(coords)
 if not ls.intersects(roi):continue
 if t.get('railway') in ['rail','light_rail'] and t.get('tunnel')!='yes' and t.get('bridge')!='yes':rail.append(ls)
 if t.get('barrier') in ['wall','fence','retaining_wall'] and t.get('access') not in ['yes','permissive']:walls.append(ls)
 if len(coords)>=4 and w['nodes'][0]==w['nodes'][-1]:
  p=shapely.make_valid(Polygon(coords))
  if t.get('natural')=='water' or t.get('waterway')=='riverbank':waters.append(p)
  if t.get('access') in ['private','no'] and t.get('landuse') in ['industrial','commercial','residential','military']:restricted.append(p)
railunion=unary_union(rail);wallunion=unary_union(walls)
# Open only explicitly mapped gates and level crossings; bridges/tunnels handled at network level.
if gates:wallunion=wallunion.difference(unary_union(gates).buffer(2))
if crossings:railunion=railunion.difference(unary_union(crossings).buffer(3))
privateunion=unary_union(restricted)
barriers=unary_union([railunion,wallunion,unary_union(waters),unary_union(restricted)])
shapely.prepare(barriers)
blocked_nodes={k for k,n in nodes.items() if n.get('tags',{}).get('access') in ['no','private'] and n.get('tags',{}).get('foot') not in ['yes','designated','permissive']}
allowed={'footway','pedestrian','path','steps','residential','living_street','service','unclassified','tertiary','secondary','primary','tertiary_link','secondary_link','primary_link','track'}
adj=collections.defaultdict(list);edges=[];excluded=collections.Counter();missing=0
for k,w in ways.items():
 t=w.get('tags',{});h=t.get('highway')
 if h not in allowed:continue
 if t.get('foot') in ['no','private'] or (t.get('access') in ['no','private','customers'] and t.get('foot') not in ['yes','designated','permissive']):excluded['access']+=1;continue
 if h in ['primary','secondary','tertiary','primary_link','secondary_link','tertiary_link'] and (t.get('sidewalk') in ['separate','no'] or t.get('sidewalk:left')=='separate' or t.get('sidewalk:right')=='separate') and t.get('foot') not in ['yes','designated']:excluded['sidewalk_separate_or_no']+=1;continue
 for a,b in zip(w['nodes'][:-1],w['nodes'][1:]):
  if a not in xy or b not in xy:missing+=1;continue
  if a in blocked_nodes or b in blocked_nodes:continue
  ls=LineString([xy[a],xy[b]])
  if not ls.intersects(roi):continue
  # Existing graph connectivity is retained, never join lines merely because they cross.
  elevated=t.get('bridge')=='yes' or t.get('tunnel')=='yes' or t.get('layer') not in [None,'0']
  if not elevated and ls.intersects(railunion):excluded['unverified_rail_crossing']+=1;continue
  if ls.intersects(wallunion) or ls.intersects(privateunion):
   excluded['unverified_fence_or_restricted_area']+=1;continue
  dist=ls.length
  if dist<=0:continue
  adj[a].append((b,dist));adj[b].append((a,dist));edges.append((a,b,dist,k))
ids=list(adj);index={n:i for i,n in enumerate(ids)};points=np.array([xy[n] for n in ids]);tree=cKDTree(points)
seen=set();components=[]
for n in ids:
 if n in seen:continue
 stack=[n];seen.add(n);comp=[]
 while stack:
  v=stack.pop();comp.append(v)
  for z,d in adj[v]:
   if z not in seen:seen.add(z);stack.append(z)
 components.append(comp)
print('GRAPH',len(ids),'nodes',len(edges),'edges','largest component',max(map(len,components)), 'components',len(components),flush=True)
# Approved internal park/square geometry; external named parks or OSM parks, no restricted access.
sources=[]
for r in R:
 if r['categorie'] in ['Parcuri','Scuaruri']:sources.append({'id':r['id'],'name':r['nume'],'kind':r['categorie'],'limit':500 if r['categorie']=='Parcuri' else 300,'geometry':r['geometry'],'origin':'V06 / categorie beneficiar'})
for f in geom['green']:
 t=f.get('tags',{});g=translate(shape(f['geometry']),tx,ty)
 if t.get('leisure')!='park' or t.get('access') in ['no','private','customers'] or g.intersects(study) or g.distance(study)>500:continue
 # External parks >1ha use 500m; smaller OSM parks conservatively treated as squares (300m).
 sources.append({'id':f['id'],'name':t.get('name','Spațiu verde exterior OSM'),'kind':'Parcuri' if g.area>=10000 else 'Scuaruri','limit':500 if g.area>=10000 else 300,'geometry':mapping(g),'origin':'OSM; categorie operațională exterior, acces de verificat'})
seeds={500:{},300:{}};entrances=[]
for s in sources:
 p=shape(s['geometry']);inside=shapely.covers(p,shapely.points(points));within=np.where(inside)[0].tolist();candidates=[]
 if within:
  # Internal public path nodes count as destinations, not hypothetical access through every boundary point.
  for i in within:candidates.append((i,0.,'nod de rețea în perimetrul verde'))
 # Street/footway nodes within 15m of the perimeter, with unobstructed short connector.
 ii=tree.query_ball_point(np.array(p.centroid.coords[0]),math.hypot(p.bounds[2]-p.bounds[0],p.bounds[3]-p.bounds[1])/2+25)
 from shapely.ops import nearest_points
 for i in ii:
  pt=Point(points[i]);d=p.distance(pt)
  if inside[i] or d>15:continue
  end=nearest_points(pt,p)[1];seg=LineString([pt,end])
  if seg.intersects(barriers) or seg.intersection(built).length>1:continue
  candidates.append((i,d,'conexiune de proximitate estimată ≤15 m'))
 # Avoid hundreds of identical nodes, keep source linkage for audit.
 unique={i:(d,method) for i,d,method in candidates};s['seed_count']=len(unique)
 for i,(d,method) in unique.items():
  key=ids[i];seeds[s['limit']][key]=min(seeds[s['limit']].get(key,1e10),d)
  entrances.append({'type':'Feature','geometry':mapping(Point(points[i])),'properties':{'sursa':s['id'],'tip':method,'legatura_m':d}})
 print('SOURCE',s['id'],s['name'][:30],s['limit'],len(unique),flush=True)
def dijkstra(initial,limit=800):
 best={n:d for n,d in initial.items()};heap=[(d,n) for n,d in best.items()];heapq.heapify(heap)
 while heap:
  d,n=heapq.heappop(heap)
  if d>best[n]+1e-8 or d>limit:continue
  for m,w in adj[n]:
   nd=d+w
   if nd<best.get(m,1e12) and nd<=limit:best[m]=nd;heapq.heappush(heap,(nd,m))
 return np.array([best.get(n,np.inf) for n in ids])
d500=dijkstra(seeds[500]);d300=dijkstra(seeds[300]);print('REACHABLE',sum(d500<=500),sum(d300<=300),flush=True)
# Sample route geometry, interpolate endpoint shortest paths along edges (10m steps).
samples=[];ds500=[];ds300=[];routefeatures=[]
for a,b,length,wid in edges:
 ia,ib=index[a],index[b];n=max(1,math.ceil(length/10));ts=np.linspace(0,1,n+1);qs=xy[a]+ts[:,None]*(xy[b]-xy[a]);samples.extend(qs)
 da=np.minimum(d500[ia]+ts*length,d500[ib]+(1-ts)*length);db=np.minimum(d300[ia]+ts*length,d300[ib]+(1-ts)*length);ds500.extend(da);ds300.extend(db)
 routefeatures.append({'type':'Feature','geometry':mapping(LineString([xy[a],xy[b]])),'properties':{'osm_way':wid,'lungime_m':length,'parc_m':float(min(d500[ia],d500[ib])) if np.isfinite(min(d500[ia],d500[ib])) else -1.,'scuar_m':float(min(d300[ia],d300[ib])) if np.isfinite(min(d300[ia],d300[ib])) else -1.}})
samples=np.array(samples);ds500=np.array(ds500);ds300=np.array(ds300);stree=cKDTree(samples)
# Display field: a maximum 80m local connector to the routed network; no travel across mapped barriers/buildings.
step=8.;xmin,ymin,xmax,ymax=study.bounds;xmin=math.floor((xmin-70)/step)*step;ymin=math.floor((ymin-70)/step)*step;xmax=math.ceil((xmax+70)/step)*step;ymax=math.ceil((ymax+70)/step)*step
xs=np.arange(xmin+step/2,xmax,step);ys=np.arange(ymin+step/2,ymax,step);xx,yy=np.meshgrid(xs,ys);grid=np.c_[xx.ravel(),yy.ravel()];valid=shapely.covers(study,shapely.points(grid)) & ~shapely.contains(built,shapely.points(grid));active=np.where(valid)[0];strength=np.zeros(len(grid));norm=np.ones(len(grid))*np.inf
obstacle_parts=list(built.geoms)+list(getattr(barriers,'geoms',[barriers]));obstacle_tree=shapely.STRtree(obstacle_parts)
print('RASTER',len(active),'cells',flush=True)
for start in range(0,len(active),5000):
 if start%20000==0:print('RASTER progress',start,flush=True)
 take=active[start:start+5000];q=grid[take];dist,ind=stree.query(q,k=12,distance_upper_bound=80);good=np.isfinite(dist);safe=np.minimum(ind,len(samples)-1)
 segs=shapely.linestrings(np.stack([np.repeat(q[:,None,:],12,axis=1),samples[safe]],axis=2).reshape(-1,2,2));hits=obstacle_tree.query(segs,predicate='intersects');blocked=np.zeros(len(segs),dtype=bool);blocked[hits[0]]=True;blocked=blocked.reshape(-1,12);ok=good & ~blocked
 a=(ds500[safe]+dist)/500;b=(ds300[safe]+dist)/300;v=np.minimum(a,b);v[~ok]=np.inf;best=np.min(v,axis=1);norm[take]=best;strength[take]=np.maximum(0,1-best)**.75
# In eligible green areas the destination itself is present, independent of drawing network density.
for s in sources:
 if s['seed_count']==0:continue
 p=shape(s['geometry']);mask=shapely.covers(p,shapely.points(grid)) & valid;strength[mask]=1;norm[mask]=0
field=strength.reshape(len(ys),len(xs));np.savez_compressed(O+'/Champ_accessibilite.npz',field=field,normalized_distance=norm.reshape(field.shape),extent=[xmin,xmax,ymin,ymax],resolution_m=step)
# Diagnose deficit using OSM buildings with documented residential type; no inference from industrial land.
residential=[];qualifying=[]
for f in geom['buildings']:
 if f['tags'].get('building') not in ['apartments','residential','house','detached','semidetached_house','terrace','dormitory']:continue
 p=translate(shape(f['geometry']),tx,ty)
 if not study.covers(p.representative_point()):continue
 # Candidate connection endpoints on nearest routes, check intervening buildings excluding this destination.
 pt=p.representative_point();q=np.array(pt.coords[0]);dist,ind=stree.query(q,k=24,distance_upper_bound=90);best=np.inf
 for d,i in zip(np.atleast_1d(dist),np.atleast_1d(ind)):
  if not np.isfinite(d):continue
  seg=LineString([q,samples[i]]);remaining=seg.difference(p.buffer(.75))
  if remaining.intersects(barriers) or remaining.intersection(built).length>1:continue
  v=min((ds500[i]+d)/500,(ds300[i]+d)/300);best=min(best,v)
 # Infinity is unknown connection, never equate unknown routes with proven deficit.
 if np.isfinite(best):status='deservit' if best<=1 else 'potential_deficitar'
 else:status='conexiune_neconfirmata'
 rec={'type':'Feature','geometry':mapping(p),'properties':{'osm_id':f['id'],'building':f['tags']['building'],'stare':status,'distanta_normalizata':float(best) if np.isfinite(best) else -1}}
 residential.append(rec)
 if status=='potential_deficitar':qualifying.append((pt.x,pt.y,f['id']))
# Network dijkstra was capped at 800m; destination with local connection but no reachable source needs distinguish from missing link.
# For unknown residences, confirm routable component contains a park/square, then shortest distance can exceed 800m.
# Compute uncapped graph paths once to assess such cases.
d500full=dijkstra(seeds[500],1e9);d300full=dijkstra(seeds[300],1e9)
full500=[];full300=[]
for a,b,length,wid in edges:
 ia,ib=index[a],index[b];ts=np.linspace(0,1,max(1,math.ceil(length/10))+1)
 full500.extend(np.minimum(d500full[ia]+ts*length,d500full[ib]+(1-ts)*length));full300.extend(np.minimum(d300full[ia]+ts*length,d300full[ib]+(1-ts)*length))
full500=np.array(full500);full300=np.array(full300)
for r in residential:
 if r['properties']['stare']!='conexiune_neconfirmata':continue
 p=shape(r['geometry']);pt=p.representative_point();q=np.array(pt.coords[0]);dist,ind=stree.query(q,k=24,distance_upper_bound=90);best=np.inf
 for d,i in zip(np.atleast_1d(dist),np.atleast_1d(ind)):
  if not np.isfinite(d):continue
  rem=LineString([q,samples[i]]).difference(p.buffer(.75))
  if rem.intersects(barriers) or rem.intersection(built).length>1:continue
  best=min(best,min((full500[i]+d)/500,(full300[i]+d)/300))
 if np.isfinite(best):
  r['properties']['stare']='deservit' if best<=1 else 'potential_deficitar';r['properties']['distanta_normalizata']=float(best)
  if best>1:qualifying.append((pt.x,pt.y,r['properties']['osm_id']))
# Identify 4 separated concentrations of deficit residential buildings, equal 110m symbolic radius.
markers=[]
if qualifying:
 qp=np.array([p[:2] for p in qualifying]);qt=cKDTree(qp);counts=np.array([len(v) for v in qt.query_ball_point(qp,150)])
 for i in np.argsort(-counts):
  p=qp[i]
  if any(np.linalg.norm(p-np.array(m['center']))<310 for m in markers):continue
  if counts[i]<3:continue
  markers.append({'id':'D'+str(len(markers)+1),'center':p.tolist(),'radius_m':110,'residential_buildings_150m':int(counts[i]),'symbol':'cerc orientativ, fără valoare de limită'})
  if len(markers)>=4:break
print('RESIDENTIAL',collections.Counter(r['properties']['stare'] for r in residential),'MARKERS',markers,flush=True)
# Export working layers in real EPSG:3844 coordinates.
def savegeo(name,features):
 out=[]
 for f in features:out.append({'type':'Feature','geometry':mapping(translate(shape(f['geometry']),-tx,-ty)),'properties':f['properties']})
 json.dump({'type':'FeatureCollection','name':name,'crs':{'type':'name','properties':{'name':'urn:ogc:def:crs:EPSG::3844'}},'features':out},open(O+'/'+name+'.geojson','w'),ensure_ascii=False)
savegeo('surse_verzi',[{'type':'Feature','geometry':s['geometry'],'properties':{k:v for k,v in s.items() if k!='geometry'}} for s in sources]);savegeo('retea_pietonala',routefeatures);savegeo('conexiuni_verde',entrances);savegeo('locuinte_analizate',residential);savegeo('limite',[{'geometry':mapping(study),'properties':{'tip':'studiu'}},{'geometry':mapping(site),'properties':{'tip':'interventie'}}]);savegeo('spatii_verzi_V06',[{'geometry':r['geometry'],'properties':{k:v for k,v in r.items() if k not in ['geometry','label_xy','pairs']}} for r in R]);savegeo('marcaje_deficit',[{'geometry':mapping(Point(m['center'])),'properties':{k:v for k,v in m.items() if k!='center'}} for m in markers]);savegeo('cladiri_CAD',[{'geometry':mapping(p),'properties':{'tip':'cladire'}} for p in built.geoms]);
summary={'network_nodes':len(ids),'network_edges':len(edges),'network_components':len(components),'largest_component_nodes':max(map(len,components)),'excluded':dict(excluded),'missing_segments':missing,'sources_internal':16,'sources_external':len(sources)-16,'sources_without_connection':[s['id'] for s in sources if s['seed_count']==0],'residential_status_counts':dict(collections.Counter(r['properties']['stare'] for r in residential)),'markers':markers,'study_area_m2':study.area,'method':'Distanțe pe graf pietonal OSM; puncte de acces inferate din conexiuni; halo grafic cu legătură locală ≤80m, bariere și clădiri filtrate. Fără indicator de suprafață deservită sau populație.','date_sources':'OSM 17.10.2026, DWG/PDF, categorii beneficiar V06','raster_extent_cad':[xmin,xmax,ymin,ymax]}
json.dump(summary,open(O+'/Raport_calcul.json','w'),ensure_ascii=False,indent=2);json.dump(markers,open(O+'/Marcaje_CAD.json','w'),ensure_ascii=False,indent=2)
print('ANALYSIS COMPLETE',flush=True)
