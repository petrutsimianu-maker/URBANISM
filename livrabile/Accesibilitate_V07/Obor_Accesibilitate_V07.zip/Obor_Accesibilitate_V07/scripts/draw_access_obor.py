import os,sys,json,math,subprocess,shutil,textwrap,zipfile
sys.path.insert(0,'/tmp/obor-ifc');os.environ['MPLCONFIGDIR']='/tmp/mpl-obor-plan'
import numpy as np,shapely
from shapely.geometry import shape,mapping,Point
from shapely.geometry.polygon import orient
from shapely.affinity import translate
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.path import Path
from matplotlib.patches import PathPatch,Circle,Rectangle
from matplotlib.collections import LineCollection
from PIL import Image
O=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));V=O+'/inputs'
S=json.load(open(O+'/Raport_calcul.json'));R=json.load(open(V+'/Spatii_verzi_individuale.json'));G=json.load(open(V+'/Geometrii_bilant.json'));L=json.load(open(V+'/Linii_plan.json'));A=np.load(O+'/Champ_accessibilite.npz');field=A['field'];xmin,xmax,ymin,ymax=A['extent'];study=shape(G['study']);site=shape(G['site']);built=shape(G['built']);sources=json.load(open(O+'/surse_verzi.geojson'))['features'];tx,ty=json.load(open(V+'/osm_registration.json'))['translation_osm_to_cad']
# Suppress disconnected source interiors in display, while retaining their inventory polygons.
xx,yy=np.meshgrid(np.linspace(xmin+float(A['resolution_m'])/2,xmax-float(A['resolution_m'])/2,field.shape[1]),np.linspace(ymin+float(A['resolution_m'])/2,ymax-float(A['resolution_m'])/2,field.shape[0]));pts=shapely.points(np.c_[xx.ravel(),yy.ravel()])
for s in sources:
 if s['properties']['seed_count']==0:
  p=translate(shape(s['geometry']),tx,ty);field.ravel()[shapely.covers(p,pts)]=0
rgba=np.zeros((*field.shape,4));rgba[:,:,0]=.45-.23*field;rgba[:,:,1]=.69-.15*field;rgba[:,:,2]=.18-.12*field;rgba[:,:,3]=.62*field
Image.fromarray(np.uint8(np.flipud(rgba)*255)).save(O+'/Degrade_accessibilite.png')
subprocess.run(['gdal_translate','-q','-of','GTiff','-a_srs','EPSG:3844','-a_ullr',str(xmin-tx),str(ymax-ty),str(xmax-tx),str(ymin-ty),'-co','COMPRESS=DEFLATE',O+'/Degrade_accessibilite.png',O+'/Degrade_accessibilite_Stereo70.tif'],check=True)
plt.rcParams.update({'font.family':'DejaVu Sans','pdf.fonttype':42,'svg.fonttype':'none'})
f=plt.figure(figsize=(420/25.4,297/25.4),facecolor='white');ax=f.add_axes([.025,.163,.735,.67]);ax.axis('off');ax.set_aspect('equal');origin=np.array([626950,324600]);
def xy(q):return np.array(q)[:,:2]-origin
def parts(g):return [g] if g.geom_type=='Polygon' else [p for p in getattr(g,'geoms',[]) if p.geom_type=='Polygon']
def patch(p,c,ec='none',lw=0,z=2,alpha=1):
 paths=[];p=orient(p,1)
 for ring in [p.exterior]+list(p.interiors):
  q=xy(ring.coords);paths.append(Path(q,[Path.MOVETO]+[Path.LINETO]*(len(q)-2)+[Path.CLOSEPOLY]))
 ax.add_patch(PathPatch(Path.make_compound_path(*paths),fc=c,ec=ec,lw=lw,zorder=z,alpha=alpha))
# Muted OSM exterior parks are context; inventory totals remain V06.
ax.imshow(rgba,origin='lower',extent=[xmin-origin[0],xmax-origin[0],ymin-origin[1],ymax-origin[1]],interpolation='bilinear',zorder=2,rasterized=True)
for layer,c,lw in [('Street_line','#9da6a0',.30),('Pav_line','#c9cec8',.13),('Rail_line','#89958f',.34),('Prop_line','#c8c3b8',.12)]:ax.add_collection(LineCollection([xy(q) for q in L.get(layer,[])],colors=c,linewidths=lw,zorder=3))
color={'Parcuri':'#255237','Scuaruri':'#397c45','Fâșii plantate':'#a6b997','Spații verzi aferente locuințelor':'#bdcbbb'}
for r in R:
 for p in parts(shape(r['geometry'])):patch(p,color[r['categorie']],ec='#edf0e7',lw=.12,z=4)
for p in parts(built):patch(p,'white','#88938d',.20,5,alpha=.87)
for p in parts(study):
 q=xy(p.exterior.coords);ax.plot(q[:,0],q[:,1],color='#b15f53',lw=.85,zorder=7)
for p in parts(site):
 q=xy(p.exterior.coords);ax.plot(q[:,0],q[:,1],color='#b63b35',lw=1.05,ls=(0,(5,3)),zorder=8)
for marker in S['markers']:
 center=np.array(marker['center'])-origin;r=marker['radius_m']
 ax.add_patch(Circle(center,r,fc='#ef655d',ec='none',alpha=.10,zorder=9))
 for factor,lw in [(1,.95),(.80,.85),(.59,.75),(.37,.65)]:ax.add_patch(Circle(center,r*factor,fc='none',ec='#e45b53',lw=lw,alpha=.75,zorder=10))
 ax.add_patch(Circle(center,8,fc='#e45b53',ec='none',alpha=.85,zorder=11));ax.text(center[0],center[1]+r+22,marker['id'],ha='center',fontsize=7,color='#b7413c',weight='bold',zorder=12,bbox=dict(fc='white',ec='none',pad=1,alpha=.85))
bb=study.bounds;ax.set(xlim=(bb[0]-origin[0]-90,bb[2]-origin[0]+90),ylim=(bb[1]-origin[1]-50,bb[3]-origin[1]+65))
ax.annotate('',xy=(.075,.975),xytext=(.075,.88),xycoords='axes fraction',arrowprops={'arrowstyle':'-|>','lw':1,'color':'#314d3b'});ax.text(.075,.985,'N',transform=ax.transAxes,ha='center',fontsize=9,color='#314d3b')
sx=bb[0]-origin[0]+70;sy=bb[1]-origin[1]-5
ax.add_patch(Rectangle((sx-30,sy-70),580,110,fc='white',ec='none',zorder=15,alpha=.95))
for j in range(2):ax.add_patch(Rectangle((sx+j*250,sy),250,9,fc='#314d3b' if j==0 else 'white',ec='#314d3b',lw=.5,zorder=16))
for d,label in [(0,'0'),(250,'250'),(500,'500 m')]:ax.text(sx+d,sy-15,label,ha='center',va='top',fontsize=6.5,color='#586b5c',zorder=17)
f.text(.043,.951,'OBOR / BUCUREȘTI',fontsize=10,weight='bold',color='#355e40');f.text(.043,.909,'Accesibilitatea spațiilor verzi',fontsize=26,color='#283e30');f.text(.043,.875,'ZONA OBOR, BUCUREȘTI  /  PARCURI 500 m · SCUARURI 300 m  /  ANALIZĂ PIETONALĂ ORIENTATIVĂ',fontsize=8,color='#6e7b71');f.text(.956,.913,'07',ha='right',fontsize=28,color='#a8b49c')
f.lines.append(plt.Line2D([.767,.767],[.165,.83],transform=f.transFigure,color='#dce2d6',lw=.7));x=.792
f.text(x,.818,'DESERVIREA PIETONALĂ',fontsize=10,weight='bold',color='#283e30')
f.text(x,.782,'500 m',fontsize=25,color='#315c39');f.text(x,.758,'până la parcuri',fontsize=8,color='#68786b');f.text(x+.105,.782,'300 m',fontsize=25,color='#537d41');f.text(x+.105,.758,'până la scuaruri',fontsize=8,color='#68786b')
f.text(x,.712,'LEGENDĂ',fontsize=9,weight='bold',color='#283e30')
for j,name in enumerate(color):
 y=.681-j*.032;f.patches.append(Rectangle((x,y-.002),.012,.011,transform=f.transFigure,fc=color[name],ec='none'));label='Spații aferente locuințelor' if name.startswith('Spații') else name;f.text(x+.019,y,label,fontsize=7.4,color='#4b5d4e')
for j,(label,col,ls) in enumerate([('Limita zonei de studiu','#b15f53','-'),('Limita intervenției','#b63b35','--')]):
 y=.531-j*.029;f.lines.append(plt.Line2D([x,x+.026],[y,y],transform=f.transFigure,color=col,lw=1,ls=ls));f.text(x+.033,y-.004,label,fontsize=7.4,color='#4b5d4e')
# Continuous legend refers to normalized distance, not vegetation density or a single common metre scale.
grad=f.add_axes([x,.443,.153,.018]);t=np.linspace(1,0,256);im=np.zeros((1,256,4));im[0,:,0]=.45-.23*t;im[0,:,1]=.69-.15*t;im[0,:,2]=.18-.12*t;im[0,:,3]=.62*t;grad.imshow(im,aspect='auto');grad.axis('off')
f.text(x,.475,'Apropiere pe rețeaua pietonală',fontsize=7.8,color='#315c39');f.text(x,.428,'aproape',fontsize=6.8,color='#6e7b71');f.text(x+.153,.428,'prag de acces',ha='right',fontsize=6.8,color='#6e7b71')
f.text(x,.392,'Intensitatea culorii indică apropierea\npietonală de parcuri și scuaruri.',fontsize=7.5,linespacing=1.45,color='#4b5d4e')
for rr in [.011,.008,.005]:f.patches.append(Circle((x+.014,.346),rr,transform=f.transFigure,fc='none',ec='#e45b53',lw=.7,alpha=.8))
f.text(x+.035,.350,'Zone construite potențial',fontsize=7.3,color='#a64f46');f.text(x+.035,.333,'deficitare · marcaj orientativ',fontsize=7.3,color='#a64f46')
f.text(x,.290,'LECTURA ANALIZEI',fontsize=8.4,weight='bold',color='#283e30')
n=len(S['markers']);conclusion=f'Deservirea este inegală. Sunt\nevidențiate {n} nuclee rezidențiale\npotențial deficitare, în afara\npragurilor analizate.' if n else 'Datele nu susțin delimitarea\nunor nuclee deficitare certe.\nConexiunile lipsă necesită\nverificare suplimentară.'
f.text(x,.264,conclusion,va='top',fontsize=8,linespacing=1.5,color='#4b5d4e')
f.text(.043,.141,'Cum se citește: verdele se estompează până la pragul de acces; roșul semnalează concentrări deficitare, fără a delimita exact aria lor.',fontsize=7.8,color='#53664f')
f.lines.append(plt.Line2D([.043,.956],[.117,.117],transform=f.transFigure,color='#dce2d6',lw=.7))
f.text(.043,.094,'METODĂ: distanțe pe graf OSM; accesuri estimate după conexiunile cartografiate. Halo grafic cu legături locale ≤80 m, filtrate de bariere și clădiri.',fontsize=7,color='#68786b')
f.text(.043,.074,'SV-053: conexiune publică neconfirmată, fără zonă de deservire atribuită. Marcajele roșii au dimensiune egală; nu exprimă numărul de locuitori.',fontsize=7,color='#68786b')
f.text(.043,.054,'Fără procent teritorial/populațional: câmpul verde este o interpolare de reprezentare, nu o limită verificată a accesului la fiecare parcelă.',fontsize=7,color='#68786b')
f.text(.043,.032,'Surse: DWG/PDF + clasificare beneficiar V06 + © OpenStreetMap contributors (17.10.2026, ODbL). Analiză pentru proiect școlar.',fontsize=6.8,color='#83907e');f.text(.956,.032,'18.10.2026 · A3 PEISAJ',ha='right',fontsize=6.8,color='#83907e')
f.savefig(O+'/Obor_Accesibilitate_V07_A3.pdf');f.savefig(O+'/Obor_Accesibilitate_V07_A3.png',dpi=300);f.savefig(O+'/Obor_Accesibilitate_V07_A3.svg');f.savefig(O+'/preview.png',dpi=110);plt.close(f)
print('DRAWING COMPLETE',flush=True)
