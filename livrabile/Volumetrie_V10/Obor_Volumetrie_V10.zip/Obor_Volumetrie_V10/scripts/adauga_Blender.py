import bpy,json,math,os
from mathutils import Vector
from mathutils.geometry import tessellate_polygon
O='/workspace/Obor_Volumetrie_V10';S=json.load(open(O+'/Slaburi_V10.json'));ORIGIN=(626950,324600)
bpy.ops.wm.open_mainfile(filepath='/workspace/Obor_Axonometrie_V09/Obor_Volumetrie_V09.blend')
parent=bpy.data.collections.new('09_Slaburi_colorate_V10');bpy.context.scene.collection.children.link(parent);cols={};mats={}
for r in S:
 key=r['color_name']
 if key in cols:continue
 col=bpy.data.collections.new('Slaburi_'+key);parent.children.link(col);cols[key]=col
 rgb=tuple(v/255 for v in r['rgb']);mat=bpy.data.materials.new('Slab_'+key);mat.diffuse_color=(*rgb,1);mat.use_nodes=True;nt=mat.node_tree;em=nt.nodes.new('ShaderNodeEmission');linear=tuple(v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in rgb);em.inputs['Color'].default_value=(*linear,1);em.inputs['Strength'].default_value=1;nt.links.new(em.outputs['Emission'],nt.nodes.get('Material Output').inputs['Surface']);mats[key]=mat
for r in S:
 verts=[];loops=[]
 for ring in r['geometry']['coordinates']:
  coords=ring[:-1] if ring[0]==ring[-1] else ring;inds=[]
  for p in coords:inds.append(len(verts));verts.append((p[0]-ORIGIN[0],p[1]-ORIGIN[1],r['base_m']))
  loops.append(inds)
 n=len(verts);verts += [(x,y,z+r['thickness_m']) for x,y,z in verts];vectors=[[Vector(verts[i+n]) for i in inds] for inds in loops];lookup={tuple(Vector(verts[i+n])):i+n for inds in loops for i in inds};faces=[]
 for tri in tessellate_polygon(vectors):
  ids=[v+n if isinstance(v,int) else lookup[tuple(v)] for v in tri];faces.extend([ids,[i-n for i in reversed(ids)]])
 for inds in loops:
  for i,a in enumerate(inds):b=inds[(i+1)%len(inds)];faces.append([a,b,b+n,a+n])
 mesh=bpy.data.meshes.new(r['id']);mesh.from_pydata(verts,[],faces);mesh.update();ob=bpy.data.objects.new(r['id'],mesh);cols[r['color_name']].objects.link(ob);ob.data.materials.append(mats[r['color_name']])
 for k in ['color_name','area_m2','base_m','thickness_m','source_layer','source_handle','method']:ob[k]=r[k]
fs=bpy.context.scene.view_layers[0].freestyle_settings
for key,col in cols.items():
 ls=fs.linesets.new('Slaburi_'+key);ls.select_by_collection=True;ls.collection=col;ls.collection_negation='INCLUSIVE';ls.select_silhouette=True;ls.select_border=True;ls.select_crease=True;ls.select_contour=True;ls.select_by_visibility=True;ls.visibility='VISIBLE';ls.linestyle.color=(.18,.21,.18);ls.linestyle.thickness=.60
scene=bpy.context.scene;scene['note']='V10 — model V09 neschimbat + slaburi joase colorate; selecție contururi/culori aproximată după imagine. X roșu ignorat.';scene.render.filepath='//Axonometrie_modele_V10.png';bpy.ops.wm.save_as_mainfile(filepath=O+'/Obor_Volumetrie_V10.blend');print('Added',len(S),'slabs; rendering',flush=True);bpy.ops.render.render(write_still=True)
