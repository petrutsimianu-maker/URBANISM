import sys,json,math,collections,csv
sys.path.insert(0,'/tmp/obor-ifc')
import shapely,numpy as np
from shapely.geometry import Polygon,Point,shape,mapping,LineString
from shapely.affinity import translate
from shapely.ops import unary_union
O='/workspace/Obor_Volumetrie_V10';M=json.load(open('/workspace/Obor_Axonometrie_V09/Model_V09.json'));study=shape(M['study']);built=unary_union([shape(b['geometry']) for b in M['buildings']]);P=json.load(open(O+'/Pav_candidates.json'));palette={'Galben':[235,202,55],'Portocaliu':[218,142,60],'Albastru':[39,171,197],'Roz':[187,88,164]}
# Approximate registration of the supplied screenshot from the study-limit northern and SE vertices.
# This aligns graphical annotations only; DWG-to-model alignment is independently checked with 957 footprints.
sx=1005/(628360.603387168-626383.0371712245);sy=1089/(325803.5068163407-323661.7795363947)
def world(x,y):return (626383.0371712245+(x-375)/sx,325803.5068163407-(y-60)/sy)
def pixel(x,y):return (375+(x-626383.0371712245)*sx,60+(325803.5068163407-y)*sy)
def rect(a,b,c,d):return Polygon([world(a,b),world(c,b),world(c,d),world(a,d)])
regions=[rect(395,118,709,426),rect(287,311,358,371),Polygon([world(x,y) for x,y in [(705,398),(955,450),(1168,640),(1176,790),(1086,805),(1006,717),(865,645),(735,572)]]),rect(135,931,333,1100),rect(695,961,974,1080),rect(338,1120,443,1195),rect(592,1056,633,1110)]
yellowregion=unary_union(regions);raw=[]
for r in P:
 p=shape(r['geometry']);c=p.representative_point()
 if yellowregion.covers(c) and p.area<3500 and p.distance(built)<15:
  raw.append({'p':p,'color_name':'Galben','source_handle':r['source_handle'],'source_layer':'New_Pav_line_Pen_No__20','method':'contur DWG; selecție galben aproximată după zona marcată în imagine'})
# Trace compact cyan/magenta marked surfaces; use nearby DWG pavement enclosure when it matches in extent.
blue=[[(285,391),(294,394),(291,411),(282,415),(281,405)],[(260,441),(270,440),(267,452),(257,459),(255,451)],[(263,575),(280,568),(294,571),(298,584),(286,588),(264,584)],[(155,794),(167,793),(174,800),(172,812),(161,816),(152,810)],[(188,849),(199,847),(204,858),(199,868),(188,870)],[(206,995),(229,987),(241,1007),(214,1022),(202,1009)],[(600,861),(622,848),(635,818),(644,814),(655,819),(653,831),(636,860),(609,876),(599,873)],[(701,868),(725,860),(760,873),(755,906),(732,903),(718,892),(699,884)],[(829,528),(840,528),(848,538),(844,546),(831,543)],[(892,555),(903,554),(907,562),(903,570),(893,568)],[(1050,606),(1064,600),(1078,613),(1080,624),(1068,627),(1057,619)],[(953,664),(964,657),(969,668),(958,682),(948,680)],[(513,1183),(532,1179),(541,1197),(522,1206),(511,1198)],[(638,1170),(651,1168),(658,1188),(644,1193),(635,1187)],[(777,1115),(800,1108),(817,1116),(809,1138),(780,1143),(771,1135)],[(990,1122),(1006,1119),(1016,1127),(1011,1134),(989,1134)]]
pink=[[(497,424),(527,442),(515,464),(505,481),(481,470),(488,456),(503,463),(514,443),(493,435)],[(990,531),(1007,538),(1008,554),(1026,569),(1018,589),(1002,601),(982,589),(972,580),(975,565),(984,553),(985,543)],[(764,896),(805,911),(803,935),(770,939),(753,926)],[(840,1112),(881,1120),(876,1146),(834,1150),(833,1135)],[(590,1172),(610,1170),(614,1189),(591,1193),(585,1185)]]
# The orange strips follow the west-side street alignment in the marked image.
orange=[[(394,104),(399,106),(387,147),(368,201),(345,254),(324,299),(316,295),(338,246),(361,190),(383,132)],[(282,369),(289,373),(272,421),(250,472),(234,470),(248,426),(267,382)],[(198,532),(203,534),(191,565),(183,569),(180,564),(190,539)],[(129,681),(135,684),(113,723),(93,756),(86,754),(96,730),(114,700)],[(162,901),(170,903),(152,914),(141,927),(145,939),(136,943),(132,927),(143,912)],[(249,938),(257,939),(274,966),(269,971),(259,960)],[(128,965),(136,968),(149,991),(157,1007),(152,1012),(139,994)]]
for color,polys in [('Albastru',blue),('Roz',pink),('Portocaliu',orange)]:
 for i,coords in enumerate(polys):
  target=shapely.make_valid(Polygon([world(x,y) for x,y in coords]));chosen=target;handle='IMAGE-'+color+'-'+str(i+1);method='contur aproximat din marcajul imaginii, aliniat pe limita studiului; nu este măsurătoare'
  best=None
  for r in P:
   p=shape(r['geometry']);inter=p.intersection(target).area;iou=inter/(p.area+target.area-inter) if inter else 0
   if iou>.35 and (best is None or iou>best[0]):best=(iou,r,p)
  if best:
   chosen=best[2];handle=best[1]['source_handle'];method='contur DWG ales prin corespondentă aproximată cu marcajul '+color+' din imagine'
  raw.append({'p':chosen,'color_name':color,'source_handle':handle,'source_layer':'New_Pav_line_Pen_No__20' if best else 'REFERINTA_IMAGINE','method':method})
# Preserve explicit cyan/magenta/orange priority over bulk yellow selection.
raw.sort(key=lambda r:r['color_name']=='Galben');slabs=[];used=Polygon();builtclip=built.buffer(.04)
for r in raw:
 p=r['p'].intersection(study).difference(builtclip).difference(used)
 parts=[p] if p.geom_type=='Polygon' else [q for q in getattr(p,'geoms',[]) if q.geom_type=='Polygon']
 for q in parts:
  if q.area<.30:continue
  rr={k:v for k,v in r.items() if k!='p'};rr.update(id='AL-'+str(len(slabs)+1).zfill(3),geometry=mapping(q),area_m2=q.area,rgb=palette[r['color_name']],base_m=.08,thickness_m=.12);slabs.append(rr);used=unary_union([used,q])
assert len(slabs)>30 and used.intersection(built).area<.001
json.dump(slabs,open(O+'/Slaburi_V10.json','w'),ensure_ascii=False)
summary={'slab_count':len(slabs),'area_m2':sum(r['area_m2'] for r in slabs),'counts_by_color':dict(collections.Counter(r['color_name'] for r in slabs)),'area_by_color':{c:sum(r['area_m2'] for r in slabs if r['color_name']==c) for c in palette},'thickness_m':.12,'base_m':.08,'building_overlap_m2':used.intersection(built).area,'color_assignment':'Aproximată după imagine; DWG-ul nu păstrează cele patru culori. Zonele X roșu sunt ignorate.','palette':palette};json.dump(summary,open(O+'/Rezumat_alei_V10.json','w'),ensure_ascii=False,indent=2)
with open(O+'/Suprafete_slaburi_V10.csv','w',encoding='utf-8-sig',newline='') as f:
 fields=['id','color_name','source_layer','source_handle','area_m2','base_m','thickness_m','method'];w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore',delimiter=';');w.writeheader();w.writerows(slabs)
tx,ty=json.load(open('/workspace/URBANISM-v02/osm_registration.json'))['translation_osm_to_cad'];json.dump({'type':'FeatureCollection','crs':{'type':'name','properties':{'name':'urn:ogc:def:crs:EPSG::3844'}},'features':[{'type':'Feature','geometry':mapping(translate(shape(r['geometry']),-tx,-ty)),'properties':{k:v for k,v in r.items() if k not in ['geometry','rgb']}} for r in slabs]},open(O+'/Slaburi_V10_Stereo70.geojson','w'),ensure_ascii=False)
print(json.dumps(summary,ensure_ascii=False,indent=2),flush=True)
