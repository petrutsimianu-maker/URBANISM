import sys,json,collections,math
sys.path.insert(0,'/tmp/obor-ifc')
import ezdxf,numpy as np,shapely
from scipy.spatial import cKDTree
from shapely.geometry import Polygon,shape,mapping
from shapely.affinity import affine_transform
O='/workspace/Obor_Volumetrie_V10';D=ezdxf.readfile(O+'/model_alei.dxf');C=json.load(open('/workspace/URBANISM-v02/cad_geometry.json'));old=[];new=[]
for e in C:
 if e['layer']=='GREEN' and e['closed']:old.append(Polygon([p[:2] for p in e['points']]))
for e in D.modelspace().query('LWPOLYLINE'):
 if 'GREEN' in e.dxf.layer and e.closed:new.append(Polygon([(p[0]*.001,p[1]*.001) for p in e.get_points()]))
old.sort(key=lambda p:p.area);new.sort(key=lambda p:p.area);assert len(old)==len(new)==7
A=[];b=[]
for p,q in zip(new,old):
 x,y=p.centroid.coords[0];X,Y=q.centroid.coords[0];A.extend([[x,-y,1,0],[y,x,0,1]]);b.extend([X,Y])
a,r,dx,dy=np.linalg.lstsq(A,b,rcond=None)[0];transform=[a,-r,r,a,dx,dy];scale=math.hypot(a,r);angle=math.degrees(math.atan2(r,a));errors=[affine_transform(p,transform).hausdorff_distance(q) for p,q in zip(new,old)];assert max(errors)<.02
M=json.load(open('/workspace/URBANISM-v02/model_data.json'));refs=[shape(v['geometry']) for v in M['buildings']];tree=cKDTree([p.centroid.coords[0] for p in refs]);matches=[];entities=[]
from ezdxf.path import make_path
for e in D.modelspace():
 if e.dxftype()=='LWPOLYLINE':
  pts=[(p.x*.001,p.y*.001) for p in make_path(e).flattening(30,segments=8)];closed=e.closed
 elif e.dxftype()=='LINE':pts=[(e.dxf.start.x*.001,e.dxf.start.y*.001),(e.dxf.end.x*.001,e.dxf.end.y*.001)];closed=False
 elif e.dxftype() in ['CIRCLE','ARC']:
  pts=[(p.x*.001,p.y*.001) for p in make_path(e).flattening(30,segments=8)];closed=e.dxftype()=='CIRCLE'
 else:continue
 coords=[(a*x-r*y+dx,r*x+a*y+dy) for x,y in pts];entities.append({'handle':e.dxf.handle,'layer':e.dxf.layer,'closed':closed,'points':coords})
 if 'Const_polygon' in e.dxf.layer and closed and len(coords)>3:
  p=shapely.make_valid(Polygon(coords))
  if p.geom_type!='Polygon' or p.area<2:continue
  ds,js=tree.query(p.centroid.coords[0],k=3,distance_upper_bound=3)
  for d,j in zip(ds,js):
   if not np.isfinite(d):continue
   q=refs[j];inter=p.intersection(q).area
   if inter/(p.area+q.area-inter)>.97:
    matches.append({'handle':e.dxf.handle,'ref_index':int(j),'hausdorff_m':p.hausdorff_distance(q),'centroid_residual_m':float(d)});break
assert len(matches)>500,len(matches)
reg={'source_units':'mm','unit_scale':.001,'similarity_scale_after_mm_to_m':scale,'rotation_deg':angle,'translation_to_CAD':[dx,dy],'affine_from_m':transform,'green_reference_count':7,'green_hausdorff_max_m':max(errors),'building_matches_IoU97pct':len(matches),'building_median_residual_m':float(np.median([m['centroid_residual_m'] for m in matches])),'building_median_hausdorff_m':float(np.median([m['hausdorff_m'] for m in matches])),'matches':matches};json.dump(reg,open(O+'/Aliniere_DWG_V10.json','w'),indent=2);json.dump(entities,open(O+'/Geometrii_DWG_aliniate.json','w'));print({k:v for k,v in reg.items() if k!='matches'},flush=True)
