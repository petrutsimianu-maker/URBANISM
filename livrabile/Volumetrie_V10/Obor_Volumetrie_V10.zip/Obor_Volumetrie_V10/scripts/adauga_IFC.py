import sys,json,time,os
sys.path.insert(0,'/tmp/obor-ifc')
import ifcopenshell,ifcopenshell.guid
from shapely.geometry import shape
from shapely.geometry.polygon import orient
O='/workspace/Obor_Volumetrie_V10';S=json.load(open(O+'/Slaburi_V10.json'));f=ifcopenshell.open('/workspace/attachments/049d4c1f-0601-40bb-862c-d7513ec86adc/Obor_Volumetrie_V09_IFC2x3.ifc');e=f.create_entity;hist=f.by_type('IfcOwnerHistory')[0];ctx=f.by_type('IfcGeometricRepresentationContext')[0];storey=f.by_type('IfcBuildingStorey')[0]
def guid():return ifcopenshell.guid.new()
def pt(x,y,z=None):return e('IfcCartesianPoint',Coordinates=(float(x),float(y)) if z is None else (float(x),float(y),float(z)))
zdir=e('IfcDirection',DirectionRatios=(0.,0.,1.));xdir=e('IfcDirection',DirectionRatios=(1.,0.,0.));axis=e('IfcAxis2Placement3D',Location=pt(0,0,0),Axis=zdir,RefDirection=xdir)
def curve(coords):return e('IfcPolyline',Points=[pt(p[0]-626950,p[1]-324600) for p in coords])
styles={};products=[];groups={};reps={}
for r in S:
 rgb=r['rgb'];key=r['color_name']
 if key not in styles:
  col=e('IfcColourRgb',Name=key,Red=rgb[0]/255.,Green=rgb[1]/255.,Blue=rgb[2]/255.);render=e('IfcSurfaceStyleRendering',SurfaceColour=col,Transparency=0.,ReflectanceMethod='NOTDEFINED');style=e('IfcSurfaceStyle',Name='Slab_'+key,Side='BOTH',Styles=[render]);styles[key]=e('IfcPresentationStyleAssignment',Styles=[style])
 p=orient(shape(r['geometry']),1);outer=curve(p.exterior.coords)
 if p.interiors:profile=e('IfcArbitraryProfileDefWithVoids',ProfileType='AREA',OuterCurve=outer,InnerCurves=[curve(ring.coords) for ring in p.interiors])
 else:profile=e('IfcArbitraryClosedProfileDef',ProfileType='AREA',OuterCurve=outer)
 place=e('IfcAxis2Placement3D',Location=pt(0,0,r['base_m']),Axis=zdir,RefDirection=xdir);solid=e('IfcExtrudedAreaSolid',SweptArea=profile,Position=place,ExtrudedDirection=zdir,Depth=r['thickness_m']);e('IfcStyledItem',Item=solid,Styles=[styles[key]]);rep=e('IfcShapeRepresentation',ContextOfItems=ctx,RepresentationIdentifier='Body',RepresentationType='SweptSolid',Items=[solid]);definition=e('IfcProductDefinitionShape',Representations=[rep]);ob=e('IfcSlab',GlobalId=guid(),OwnerHistory=hist,Name=r['id']+' / '+key,ObjectType='Alei si suprafete joase din DWG',ObjectPlacement=e('IfcLocalPlacement',RelativePlacement=axis),Representation=definition,PredefinedType='FLOOR')
 props=[]
 for k,v in {'DWG_layer':r['source_layer'],'DWG_handle':r['source_handle'],'Culoare':key,'Suprafata_m2':r['area_m2'],'Grosime_m':r['thickness_m'],'Cota_inferioara_m':r['base_m'],'Nota':'Slab jos conform model alei.dwg; culoarea este cod grafic, fără clasificare funcțională dedusă.'}.items():props.append(e('IfcPropertySingleValue',Name=k,NominalValue=e('IfcReal',float(v)) if isinstance(v,(float,int)) else e('IfcText',v)))
 ps=e('IfcPropertySet',GlobalId=guid(),OwnerHistory=hist,Name='Obor_Slaburi_V10',HasProperties=props);e('IfcRelDefinesByProperties',GlobalId=guid(),OwnerHistory=hist,RelatedObjects=[ob],RelatingPropertyDefinition=ps);products.append(ob);groups.setdefault(key,[]).append(ob);reps.setdefault(key,[]).append(rep)
e('IfcRelContainedInSpatialStructure',GlobalId=guid(),OwnerHistory=hist,RelatedElements=products,RelatingStructure=storey)
for key,objects in groups.items():
 group=e('IfcGroup',GlobalId=guid(),OwnerHistory=hist,Name='SLABURI_'+key);e('IfcRelAssignsToGroup',GlobalId=guid(),OwnerHistory=hist,RelatedObjects=objects,RelatingGroup=group);e('IfcPresentationLayerAssignment',Name='SLABURI_'+key,AssignedItems=reps[key])
f.header.file_name.name='Obor_Volumetrie_V10_IFC2x3.ifc';f.write(O+'/Obor_Volumetrie_V10_IFC2x3.ifc');print('Preserved IFC and added',len(products),'IfcSlab objects',flush=True)
