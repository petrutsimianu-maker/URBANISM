import os,sys,json,math,random
os.environ['MPLCONFIGDIR']='/tmp/mpl-obor';
import numpy as np,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as Patch, Circle, PathPatch
from matplotlib.path import Path
from shapely.geometry.polygon import orient
from matplotlib.collections import LineCollection,PolyCollection
from shapely.geometry import shape,Point,Polygon,box
from shapely.ops import unary_union
from matplotlib.backends.backend_pdf import PdfPages
from pathlib import Path as FilePath
O=str(FilePath(__file__).resolve().parents[1]);M=json.load(open(O+'/model_data.json'));D=json.load(open(O+'/cad_geometry.json'))
study=shape(M['study']);site=shape(M['site']);green=shape(M['green'])
B=[(shape(b['geometry']),b['height_m']) for b in M['buildings']]
random.seed(42)
trees=[]
for p in green.geoms if green.geom_type=='MultiPolygon' else [green]:
 minx,miny,maxx,maxy=p.bounds
 for x in np.arange(minx+4,maxx,9):
  for y in np.arange(miny+4,maxy,9):
   q=Point(x+random.uniform(-2,2),y+random.uniform(-2,2))
   if p.buffer(-1).contains(q):trees.append((q.x,q.y,random.uniform(5,7),random.uniform(2,3)))
json.dump(trees,open(O+'/trees_schematic.json','w'))
angle=math.radians(26);elev=math.radians(40);ca,sa=math.cos(angle),math.sin(angle)
origin=np.array([626950,324600])
def proj(pts,z=0):
 pts=np.asarray(pts);q=pts[:,:2]-origin;u=q[:,0]*ca+q[:,1]*sa;d=-q[:,0]*sa+q[:,1]*ca
 zz=np.array(z) if np.ndim(z)>0 else np.full(len(q),z)
 return np.column_stack([u,d*math.sin(elev)+zz*math.cos(elev)])
def depth(pts):
 p=np.asarray(pts);q=p[:,:2]-origin;return np.mean((-q[:,0]*sa+q[:,1]*ca)*math.cos(elev)-p[:,2]*math.sin(elev))
def parts(g):return [g] if g.geom_type=='Polygon' else [p for p in getattr(g,'geoms',[]) if p.geom_type=='Polygon']
def boundary(ax,g,c,lw,ls='-'):
 for p in parts(g):
  q=proj(p.exterior.coords);ax.plot(q[:,0],q[:,1],color=c,lw=lw,ls=ls,zorder=6)
def make_page(detail=False):
 fig=plt.figure(figsize=(420/25.4,297/25.4),facecolor='white');ax=fig.add_axes([.035,.19,.93,.65]);ax.set_aspect('equal');ax.axis('off')
 extent=site.buffer(230).envelope if detail else study.buffer(95).envelope
 drawzone=extent
 # white ground and neutral cartography
 for layers,col,lw in [(['Prop_line'],'#dce1df',.18),(['Pav_line'],'#d9dedb',.22),(['Street_line'],'#c8cfcd',.30),(['Rail_line'],'#a7afac',.45)]:
  seg=[]
  for en in D:
   if en['layer'] not in layers:continue
   pts=np.array(en['points'])
   if not (pts[:,0].max()>extent.bounds[0] and pts[:,0].min()<extent.bounds[2] and pts[:,1].max()>extent.bounds[1] and pts[:,1].min()<extent.bounds[3]):continue
   if en['closed']:pts=np.vstack([pts,pts[0]])
   seg.append(proj(pts))
  ax.add_collection(LineCollection(seg,colors=col,linewidths=lw,zorder=1))
 for p in parts(green.intersection(extent)):
  ax.add_patch(Patch(proj(p.exterior.coords),fc='#a7c978',ec='#799b56',lw=.35,zorder=2))
 # masses and schematic tree crowns, sorted back to front
 prim=[]
 for p,h in B:
  if not p.intersects(extent):continue
  p=orient(p,sign=1.0)
  outer=not study.covers(p.representative_point())
  ps=list(p.exterior.coords);roof=[]
  for x,y in ps:roof.append([x,y,h])
  wallsegments=[(ring.coords[i],ring.coords[i+1]) for ring in [p.exterior]+list(p.interiors) for i in range(len(ring.coords)-1)]
  for a,b in wallsegments:
   face=np.array([[a[0],a[1],0],[b[0],b[1],0],[b[0],b[1],h],[a[0],a[1],h]])
   col='#fafbfa' if outer else ('#f0f2ef' if (b[0]-a[0])>0 else '#f7f8f6')
   prim.append((depth(face),proj(face,face[:,2]),col,'#d6dcd8' if outer else '#a6b2a8',.16 if not detail else .24))
  face=np.array(roof)
  roofpaths=[]
  for ring in [p.exterior]+list(p.interiors):
   coords=proj(ring.coords,h);codes=[Path.MOVETO]+[Path.LINETO]*(len(coords)-2)+[Path.CLOSEPOLY];roofpaths.append(Path(coords,codes))
  roofpath=Path.make_compound_path(*roofpaths)
  prim.append((depth(face),roofpath,'#ffffff','#c8d0c9' if outer else '#8e9e91',.23 if not detail else .34))
 for x,y,h,r in trees:
  if not extent.contains(Point(x,y)):continue
  # compact geometric crown; schematic distribution, not surveyed trees
  coords=[]
  for k in range(10):
   t=2*math.pi*k/10;coords.append([x+r*math.cos(t),y+r*math.sin(t),h-1+1.1*math.sin(t)])
  a=np.array(coords);prim.append((depth(a)-.1,proj(a,a[:,2]),'#79a957','#6f9651',.2))
  trunk=np.array([[x,y,0],[x,y,h-1]]);prim.append((depth(trunk),proj(trunk,trunk[:,2]),None,'#8c9c73',.4))
 prim.sort(key=lambda x:-x[0])
 for dep,poly,fc,ec,lw in prim:
  if fc is None:ax.plot(poly[:,0],poly[:,1],color=ec,lw=lw,zorder=3)
  else:ax.add_patch((PathPatch(poly,fc=fc,ec=ec,lw=lw,zorder=3,joinstyle='round') if isinstance(poly,Path) else Patch(poly,fc=fc,ec=ec,lw=lw,zorder=3,joinstyle='round')))
 boundary(ax,study,'#69766c',.75,(0,(7,5)));boundary(ax,site,'#b85b51',1.1,(0,(5,3)))
 q=proj(extent.exterior.coords);ax.set_xlim(q[:,0].min()-15,q[:,0].max()+15);ax.set_ylim(q[:,1].min()-15,q[:,1].max()+45)
 # north arrow aligned to projected CAD Y, whose true geographic bearing is unverified
 p0=np.array([.92,.85]);direction=np.array([sa,ca*math.sin(elev)]);direction=direction/np.linalg.norm(direction)*.075
 ax.annotate('',xy=p0+direction,xytext=p0,xycoords='axes fraction',arrowprops=dict(arrowstyle='->',color='#68766b',lw=.85))
 ax.text(.90,.83,'N*',transform=ax.transAxes,fontsize=8,color='#68766b')
 # label site at a selected boundary point, drawn outside masses
 anchor=proj([list(site.exterior.coords)[0]])[0]
 if detail:
  ax.annotate('ZONA DE INTERVENȚIE',xy=anchor,xytext=(28,-22),textcoords='offset points',fontsize=7.5,color='#a6534a',arrowprops=dict(arrowstyle='-',color='#b85b51',lw=.55),zorder=8)
 num='02' if detail else '01'
 fig.text(.045,.947,'OBOR  /  BUCUREȘTI',fontsize=11,color='#637e52',weight='bold')
 fig.text(.045,.903,'Spații verzi și fond construit',fontsize=25,color='#26382c',weight='medium')
 fig.text(.045,.869,'AXONOMETRIE DE DETALIU · INTERVENȚIE ȘI VECINĂTĂȚI' if detail else 'AXONOMETRIE GENERALĂ · ZONA DE STUDIU',fontsize=10,color='#6f7b72')
 fig.text(.947,.907,num,fontsize=32,color='#b4c4a8',ha='right')
 # line separating drawing and footer
 fig.lines.append(plt.Line2D([.045,.955],[.175,.175],transform=fig.transFigure,color='#d4ddd1',lw=.65))
 labels=[('#a7c978','Verde existent · sursă DWG*'),('#f5f7f3','Fond construit · volume estimate'),('#79a957','Arbori schematici în suprafețele GREEN')]
 for i,(c,txt) in enumerate(labels):
  x=.045+i*.29;fig.patches.append(plt.Rectangle((x,.139),.012,.012,transform=fig.transFigure,facecolor=c,edgecolor='#a9b4a5',linewidth=.5));fig.text(x+.018,.14,txt,fontsize=7.5,color='#455346')
 fig.text(.045,.112,'— —  Limită studiu',fontsize=7.5,color='#69766c');fig.text(.24,.112,'— —  Limită intervenție',fontsize=7.5,color='#b85b51')
 fig.text(.045,.079,'* Acoperire verde incompletă; caracterul existent al GREEN a fost confirmat de beneficiar. Arbori amplasați schematic.',fontsize=7.2,color='#6a756d')
 fig.text(.045,.059,'Geometrie: DWG furnizat; limite: PDF furnizat. Înălțimi integral estimate morfologic. Situația actuală nu este verificată integral.',fontsize=7.2,color='#6a756d')
 fig.text(.045,.039,'Studiu școlar · versiune preliminară 17.10.2026 · teren plan · proiecție paralelă · N* = axa +Y CAD, orientare geografică neconfirmată',fontsize=7,color='#849084')
 fig.text(.955,.039,'A3 / PEISAJ',fontsize=7,color='#849084',ha='right')
 return fig
with PdfPages(O+'/Axonometrii_Obor_A3.pdf') as pdf:
 for detail,name in [(False,'01_Axonometrie_generala'),(True,'02_Axonometrie_interventie')]:
  f=make_page(detail);pdf.savefig(f);f.savefig(O+'/'+name+'.pdf');f.savefig(O+'/'+name+'.png',dpi=260);plt.close(f)
print('Rendered',len(B),'masses;',len(trees),'schematic trees')
