import os
import sys,json,time
sys.path.insert(0,'/tmp/obor-ifc')
import ifcopenshell,ifcopenshell.geom,ifcopenshell.validate
O=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));f=ifcopenshell.open(O+'/Obor_Volumetrie_V09_IFC2x3.ifc');logger=ifcopenshell.validate.json_logger();ifcopenshell.validate.validate(f,logger);print('Schema issues',len(logger.statements),flush=True)
json.dump(logger.statements,open(O+'/Validation_IFC_schema.json','w'),default=str,indent=2)
assert not logger.statements
products=f.by_type('IfcBuildingElementProxy');settings=ifcopenshell.geom.settings();iterator=ifcopenshell.geom.iterator(settings,f,4);count=0;guids=set()
if iterator.initialize():
 while True:
  ob=iterator.get();assert len(ob.geometry.verts)>0;count+=1;guids.add(ob.guid)
  if not iterator.next():break
expected={ob.GlobalId for ob in products};missing=[{'name':ob.Name,'guid':ob.GlobalId} for ob in products if ob.GlobalId not in guids]
print('Generated geometry',count,'/',len(products),'missing',missing[:8],flush=True)
json.dump({'schema':f.schema,'errors':len(logger.statements),'products':len(products),'generated_geometry':count,'missing':missing,'Archicad_26_import_tested':False},open(O+'/Validation_IFC_resume.json','w'),indent=2);assert not missing
