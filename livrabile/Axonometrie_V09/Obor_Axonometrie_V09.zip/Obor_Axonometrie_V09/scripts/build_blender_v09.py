import os
import bpy,json,math,os
from mathutils import Vector
from mathutils.geometry import tessellate_polygon
O=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));M=json.load(open(O+'/Model_V09.json'));L=json.load(open(O+'/inputs/Linii_plan.json'));ORIGIN=(626950,324600)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
for col in list(bpy.data.collections):
 if col.name!='Collection':bpy.data.collections.remove(col)
root=bpy.context.scene.collection;cols={}
for name in ['01_Cladiri_studiu','02_Cladiri_context','03_Parcuri','04_Scuaruri','05_Fasii_plantate','06_Verzi_locuinte','07_Baza_CAD','08_Limite']:
 c=bpy.data.collections.new(name);root.children.link(c);cols[name]=c
if bpy.data.collections.get('Collection'):bpy.data.collections.remove(bpy.data.collections['Collection'])
def mat(name,rgb):
 m=bpy.data.materials.new(name);m.diffuse_color=(*rgb,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*rgb,1);p.inputs['Roughness'].default_value=.9;nt=m.node_tree;out=nt.nodes.get('Material Output');em=nt.nodes.new('ShaderNodeEmission');linear=tuple(v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in rgb);em.inputs['Color'].default_value=(*linear,1);em.inputs['Strength'].default_value=1.;nt.links.new(em.outputs['Emission'],out.inputs['Surface']);return m
white=mat('Cladiri_albe',(1,1,1));context=mat('Context_alb',(1,1,1));colors={'Parcuri':('03_Parcuri',(0.13,.33,.23)),'Scuaruri':('04_Scuaruri',(.20,.48,.33)),'Fâșii plantate':('05_Fasii_plantate',(.34,.53,.28)),'Spații verzi aferente locuințelor':('06_Verzi_locuinte',(.39,.56,.48))};mats={k:mat(k,rgb) for k,(_,rgb) in colors.items()}
def meshpoly(name,geo,z,h,material,col):
 # Extrusion with true courtyard holes; triangulate horizontal caps via Blender tessellation.
 rings=geo['coordinates'];verts=[];loops=[]
 for ring in rings:
  coords=ring[:-1] if ring[0]==ring[-1] else ring
  inds=[]
  for p in coords:inds.append(len(verts));verts.append((p[0]-ORIGIN[0],p[1]-ORIGIN[1],z))
  loops.append(inds)
 n=len(verts);verts += [(x,y,z+h) for x,y,z in verts];faces=[]
 vectors=[[Vector(verts[i+n]) for i in inds] for inds in loops];lookup={tuple(Vector(verts[i+n])):i+n for inds in loops for i in inds}
 for tri in tessellate_polygon(vectors):
  ids=[v+n if isinstance(v,int) else lookup[tuple(v)] for v in tri];faces.append(ids);faces.append([i-n for i in reversed(ids)])
 for inds in loops:
  for i,a in enumerate(inds):b=inds[(i+1)%len(inds)];faces.append([a,b,b+n,a+n])
 mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],faces);mesh.update();ob=bpy.data.objects.new(name,mesh);cols[col].objects.link(ob);ob.data.materials.append(material)
 return ob
for r in M['volumes']:
 ob=meshpoly(r['id'],r['geometry'],r['base_m'],r['height_m']-r['base_m'],white if r['in_study'] else context,'01_Cladiri_studiu' if r['in_study'] else '02_Cladiri_context')
 for k in ['building_id','height_m','base_m','status','method','confidence','osm_id','height_source_url']:ob[k]=r.get(k,'')
 if r.get('levels') is not None:ob['levels']=r['levels']
for r in M['greens']:
 col,_=colors[r['categorie']];ob=meshpoly(r['id'],r['geometry'],.04,.035,mats[r['categorie']],col);ob['categorie']=r['categorie'];ob['suprafata_m2']=r['area_m2']
def curve(name,segments,radius,material,col):
 data=bpy.data.curves.new(name,'CURVE');data.dimensions='3D';data.resolution_u=1;data.bevel_depth=radius;data.bevel_resolution=0
 for line in segments:
  sp=data.splines.new('POLY');sp.points.add(len(line)-1)
  for dst,pt in zip(sp.points,line):dst.co=(pt[0]-ORIGIN[0],pt[1]-ORIGIN[1],.10,1)
 ob=bpy.data.objects.new(name,data);cols[col].objects.link(ob);data.materials.append(material);return ob
road=mat('Voies_gris',(.64,.69,.66));parcel=mat('Parcele_discrete',(.82,.83,.80));rail=mat('Calea_ferata',(.53,.58,.55));dark=mat('Limita_studiu',(.26,.36,.30));red=mat('Limita_interventie',(.64,.27,.23))
for name in ['Street_line','Pav_line','Prop_line','Rail_line']:
 curve(name,L.get(name,[]),.13 if name=='Prop_line' else .20,parcel if name in ['Prop_line','Pav_line'] else rail if name=='Rail_line' else road,'07_Baza_CAD')
# Dashed border curves prevent a heavy frame.
for key,material in [('study',dark),('site',red)]:
 segments=[]
 for ring in M[key]['coordinates'][:1]:
  for a,b in zip(ring,ring[1:]):
   va=Vector(a[:2]);vb=Vector(b[:2]);length=(vb-va).length
   for start in range(0,math.ceil(length),18):
    if length==0:continue
    pa=va+(vb-va)*start/length;pb=va+(vb-va)*min(start+11,length)/length;segments.append([list(pa),list(pb)])
 curve('Limita_'+key,segments,.38 if key=='study' else .60,material,'08_Limite')
# Matte ground, neutral world and soft illumination.
bpy.ops.mesh.primitive_plane_add(size=20000,location=(0,0,-.08));ground=bpy.context.object;ground.name='Teren_alb';ground.data.materials.append(white)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=8;scene.cycles.use_denoising=False;scene.cycles.max_bounces=0;scene.render.threads_mode='FIXED';scene.render.threads=6
scene.world.color=(1,1,1);scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(1,1,1,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.8
bpy.ops.object.light_add(type='AREA',location=(-1000,-1200,2500));light=bpy.context.object;light.data.energy=7000000;light.data.shape='DISK';light.data.size=4000
light.rotation_euler=(Vector((0,0,0))-light.location).to_track_quat('-Z','Y').to_euler()
angle=math.radians(26);elev=math.radians(38);c=math.cos(angle);s=math.sin(angle)
coords=M['study']['coordinates'][0];projected=[( (p[0]-ORIGIN[0])*c+(p[1]-ORIGIN[1])*s, (-(p[0]-ORIGIN[0])*s+(p[1]-ORIGIN[1])*c)*math.sin(elev)) for p in coords]
minu=min(p[0] for p in projected);maxu=max(p[0] for p in projected);minv=min(p[1] for p in projected);maxv=max(p[1] for p in projected);uc=(minu+maxu)/2;vc=(minv+maxv)/2
center=Vector((uc*c-vc/math.sin(elev)*s,uc*s+vc/math.sin(elev)*c,0))
bpy.ops.object.camera_add();camera=bpy.context.object;camera.name='Camera_Axonometrie';camera.data.type='ORTHO';camera.location=center+Vector((s*math.cos(elev),-c*math.cos(elev),math.sin(elev)))*6000;camera.rotation_euler=(center-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.clip_end=30000
scene.camera=camera;scene.render.resolution_x=4400;scene.render.resolution_y=2850;scene.render.resolution_percentage=100;aspect=scene.render.resolution_x/scene.render.resolution_y;camera.data.ortho_scale=max(maxu-minu,(maxv-minv+90)*aspect)*1.08
scene.render.image_settings.file_format='PNG';scene.render.film_transparent=False;scene.view_settings.view_transform='Standard';scene.view_settings.look='Medium High Contrast' if False else 'None';scene.view_settings.exposure=0;scene.view_settings.gamma=1
scene.render.use_freestyle=True;fs=scene.view_layers[0].freestyle_settings
for ls in list(fs.linesets):fs.linesets.remove(ls)
for name,collection,col,thickness in [('Etude',cols['01_Cladiri_studiu'],(.13,.16,.14),1.65),('Contexte',cols['02_Cladiri_context'],(.68,.72,.69),.65)]:
 ls=fs.linesets.new(name);ls.select_by_collection=True;ls.collection=collection;ls.collection_negation='INCLUSIVE';ls.select_by_edge_types=True;ls.select_silhouette=True;ls.select_border=True;ls.select_crease=True;ls.select_material_boundary=False;ls.select_contour=True;ls.select_external_contour=True;ls.select_by_visibility=True;ls.visibility='VISIBLE';ls.linestyle.color=col;ls.linestyle.thickness=thickness
scene['note']='V09: DWG + OSM 17.10.2026; heights documented or estimated in object attributes. No trees or accessibility overlay.';scene['origin_EPSG3844_E']=M['summary']['origin_stereo70'][0];scene['origin_EPSG3844_N']=M['summary']['origin_stereo70'][1];scene['angle_deg']=26.;scene['elevation_deg']=38.
scene.render.filepath='//Axonometrie_modele_V09.png'
bpy.ops.wm.save_as_mainfile(filepath=O+'/Obor_Volumetrie_V09.blend')
json.dump({'angle_deg':26,'elevation_deg':38,'orthographic_scale_m':camera.data.ortho_scale,'render_pixels':[4400,2850]},open(O+'/Camera_V09.json','w'),indent=2)
print('SAVED MODEL',len(bpy.data.objects),'objects',flush=True)
bpy.ops.render.render(write_still=True)
