import os,sys,json,math,re,csv,collections
sys.path.insert(0,'/tmp/obor-ifc')
import numpy as np,shapely
from shapely.geometry import shape,Polygon,mapping,Point
from shapely.affinity import translate
from shapely.ops import unary_union
from scipy.spatial import cKDTree
O='/workspace/Obor_Axonometrie_V09';M=json.load(open('/workspace/URBANISM-v02/model_data.json'));D=json.load(open('/workspace/URBANISM-v02/osm/osm_projected.json'));tx,ty=json.load(open('/workspace/URBANISM-v02/osm_registration.json'))['translation_osm_to_cad'];study=shape(M['study']);site=shape(M['site']);roi=study.buffer(100);R=json.load(open('/workspace/Obor_Plan2D_V06/Spatii_verzi_individuale.json'))
def number(v):
 if v is None:return None
 v=str(v).strip().lower().replace(',','.');v=v.replace('metres','').replace('meters','').replace(' m','').strip()
 if ';' in v or '-' in v or not re.fullmatch(r'\d+(\.\d+)?',v):return None
 return float(v)
def measure(t):
 h=number(t.get('height'));levels=number(t.get('building:levels'));minimum=number(t.get('min_height')) or 0.;minlevel=number(t.get('building:min_level'));roof=number(t.get('roof:height'))
 if minimum==0 and minlevel:minimum=minlevel*3.
 if h and 2<=h<=180 and minimum<h:return {'height_m':h,'base_m':minimum,'levels':levels,'status':'documentat','method':'height OSM (valoare declarată, nemăsurată independent)','confidence':'medie','roof_height_m':roof}
 if levels and .5<=levels<=50:
  h=levels*3.+(roof if roof and roof<20 else 0.)
  if h>minimum:return {'height_m':h,'base_m':minimum,'levels':levels,'status':'estimat','method':'building:levels OSM × 3,00 m + roof:height dacă există','confidence':'medie','roof_height_m':roof}
 return None
F=[]
for wid,w in D['ways'].items():
 t=w['tags']
 if not (t.get('building') or t.get('building:part')) or w['nodes'][0]!=w['nodes'][-1]:continue
 ps=[D['nodes'][n]['xy'] for n in w['nodes'] if n in D['nodes']]
 if len(ps)!=len(w['nodes']) or len(ps)<4:continue
 p=shapely.make_valid(Polygon(ps));p=translate(p,tx,ty)
 if p.area<2 or not p.intersects(roi):continue
 F.append({'id':'way/'+wid,'tags':t,'p':p,'height':measure(t),'part':t.get('building:part') not in [None,'no']})
# Multipolygon buildings absent in way-only source are preserved when present in the prior extraction.
existing={f['id'] for f in F}
for f in json.load(open('/workspace/URBANISM-v02/osm/osm_geometries.json'))['buildings']:
 if f['id'] in existing:continue
 p=translate(shape(f['geometry']),tx,ty)
 if not p.intersects(roi) or p.area<2:continue
 F.append({'id':f['id'],'tags':f['tags'],'p':p,'height':measure(f['tags']),'part':f['tags'].get('building:part') not in [None,'no']})
tree=shapely.STRtree([f['p'] for f in F]);records=[];ambiguous=[]
for i,b in enumerate(M['buildings']):
 p=shape(b['geometry'])
 if not p.intersects(roi):continue
 inside=study.covers(p.representative_point());bid='B-%04d'%(i+1)
 matches=[]
 for j in tree.query(p,predicate='intersects'):
  f=F[int(j)];inter=p.intersection(f['p']).area
  if inter<2:continue
  cadcov=inter/p.area;osmcov=inter/f['p'].area;iou=inter/(p.area+f['p'].area-inter)
  if (osmcov>=.65 or cadcov>=.65) and iou>=.20:matches.append((iou,j,inter))
 matches.sort(reverse=True);r={'id':bid,'geometry':mapping(p),'area_m2':p.area,'in_study':inside,'source_geometry':'DWG Const_polygon','height_m':float(b['height_m']),'base_m':0.,'levels':None,'status':'estimat','method':'estimare morfologică V02, de verificat','confidence':'scazuta','osm_id':'','match_iou':0.,'osm_levels_documented':False}
 valid=[m for m in matches if F[m[1]]['height'] and not F[m[1]]['part']]
 if valid:
  _,j,_=valid[0];f=F[j];r.update(f['height']);r.update(osm_id=f['id'],match_iou=valid[0][0],osm_levels_documented=f['height']['levels'] is not None)
  if len(valid)>1 and abs(valid[0][0]-valid[1][0])<.10 and abs(F[valid[0][1]]['height']['height_m']-F[valid[1][1]]['height']['height_m'])>6:r['confidence']='scazuta';ambiguous.append(bid)
 records.append(r)
# Local estimate only from geometrically comparable footprints with known OSM height/levels; no functional classification.
known=[r for r in records if r['osm_id']];kpts=np.array([shape(r['geometry']).centroid.coords[0] for r in known]);ktree=cKDTree(kpts) if len(known) else None
for r in records:
 if r['osm_id']:continue
 p=shape(r['geometry']);near=ktree.query_ball_point(np.array(p.centroid.coords[0]),220) if ktree else []
 candidates=[]
 ar=p.area/perim if (perim:=p.length)>0 else 0
 for k in near:
  ref=known[k];q=shape(ref['geometry']);ratio=r['area_m2']/ref['area_m2'];dr=p.centroid.distance(q.centroid)
  if .55<=ratio<=1.8 and .6<=ar/(q.area/q.length)<=1.65:candidates.append((dr,ref))
 candidates.sort(key=lambda x:x[0]);candidates=candidates[:7]
 if len(candidates)>=3:
  vals=[q['height_m'] for d,q in candidates];h=round(float(np.median(vals))/1.5)*1.5
  r.update(height_m=max(3.,min(48.,h)),method='mediană locală (≥3 amprente comparabile, ≤220 m); fără verificare stradală',confidence='scazuta',analogue_ids=','.join(q['id'] for d,q in candidates))
# Build disjoint volumes: clip OSM building parts to CAD; remainder retains CAD outline and parent height.
volumes=[];split_buildings=0
for r in records:
 p=shape(r['geometry']);pieces=[]
 for j in tree.query(p,predicate='intersects'):
  f=F[int(j)]
  if not f['part'] or not f['height']:continue
  q=p.intersection(f['p'])
  if q.area>=4 and q.area/f['p'].area>=.55:pieces.append((q.area,f,q))
 pieces.sort(key=lambda x:x[0]);used=Polygon();sub=[]
 for area,f,q in pieces:
  q=q.difference(used)
  polygons=[q] if q.geom_type=='Polygon' else [v for v in getattr(q,'geoms',[]) if v.geom_type=='Polygon']
  for poly in polygons:
   if poly.area<3:continue
   v={**r,**f['height'],'geometry':mapping(poly),'osm_id':f['id'],'area_m2':poly.area,'is_part':True,'osm_levels_documented':f['height']['levels'] is not None};sub.append(v);used=unary_union([used,poly])
 remainder=p.difference(used)
 ps=[remainder] if remainder.geom_type=='Polygon' else [v for v in getattr(remainder,'geoms',[]) if v.geom_type=='Polygon']
 for poly in ps:
  if poly.area>.01:sub.append({**r,'geometry':mapping(poly),'area_m2':poly.area,'is_part':False})
 if len(sub)>1:split_buildings+=1
 for j,v in enumerate(sub):v['building_id']=r['id'];v['id']=r['id']+'-'+str(j+1).zfill(2);volumes.append(v)
 assert abs(sum(v['area_m2'] for v in sub)-p.area)<.02,(r['id'],p.area,sum(v['area_m2'] for v in sub))
# Explicit minimum-height tags apply only to parts; whole footprint volumes start at ground.
for v in volumes:
 if not v['is_part']:v['base_m']=0.
 v['height_source_url']='https://www.openstreetmap.org/'+v['osm_id'] if v['osm_id'] else ''
 v['date_source']='OSM 17.10.2026; elaborare 19.10.2026'
inside=[r for r in records if r['in_study']];vi=[v for v in volumes if v['in_study']]
summary={'buildings_total_model':len(records),'buildings_in_study':len(inside),'volumes_in_study':len(vi),'volumes_total':len(volumes),'buildings_split':split_buildings,'height_documented_buildings':sum(r['status']=='documentat' for r in inside),'levels_documented_buildings':sum(r['osm_levels_documented'] and r['status']!='documentat' for r in inside),'height_estimated_buildings':sum(r['status']=='estimat' for r in inside),'morphological_estimates_buildings':sum(not r['osm_id'] for r in inside),'volumes_status':dict(collections.Counter(v['status'] for v in vi)),'volumes_with_osm_levels':sum(v['osm_levels_documented'] for v in vi),'height_range_m':[min(v['height_m'] for v in vi),max(v['height_m'] for v in vi)],'low_confidence_volumes':sum(v['confidence']=='scazuta' for v in vi),'ambiguous_buildings':ambiguous,'study_area_m2':study.area,'green_area_m2':sum(r['area_m2'] for r in R),'green_count':len(R),'origin_cad':[626950,324600],'origin_stereo70':[626950-tx,324600-ty],'source_snapshot':'17.10.2026','date':'19.10.2026'}
json.dump({'study':mapping(study),'site':mapping(site),'buildings':records,'volumes':volumes,'greens':R,'summary':summary},open(O+'/Model_V09.json','w'),ensure_ascii=False)
json.dump(summary,open(O+'/Rezumat_V09.json','w'),ensure_ascii=False,indent=2)
with open(O+'/Inaltimi_cladiri_V09.csv','w',encoding='utf-8-sig',newline='') as f:
 cols=['id','building_id','in_study','area_m2','height_m','base_m','levels','status','method','confidence','osm_id','match_iou','height_source_url','source_geometry','date_source'];w=csv.DictWriter(f,fieldnames=cols,delimiter=';',extrasaction='ignore');w.writeheader();w.writerows(volumes)
used=[{'id':f['id'],'tags':f['tags'],'geometry':mapping(f['p']),'part':f['part']} for f in F];json.dump(used,open(O+'/Surse_OSM_selectate_CAD.json','w'),ensure_ascii=False)
print(json.dumps(summary,ensure_ascii=False,indent=2),flush=True)
