import os
import sys,json,time,math,os
sys.path.insert(0,'/tmp/obor-ifc')
import ifcopenshell,ifcopenshell.guid,ifcopenshell.geom
from shapely.geometry import shape
from shapely.geometry.polygon import orient
O=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));M=json.load(open(O+'/Model_V09.json'));F=ifcopenshell.file(schema='IFC2X3');e=F.create_entity
person=e('IfcPerson',FamilyName='Codex');org=e('IfcOrganization',Name='URBANISM - studiu scolar');po=e('IfcPersonAndOrganization',ThePerson=person,TheOrganization=org);app=e('IfcApplication',ApplicationDeveloper=org,Version='V09',ApplicationFullName='Obor geometry export',ApplicationIdentifier='OBOR');hist=e('IfcOwnerHistory',OwningUser=po,OwningApplication=app,ChangeAction='ADDED',CreationDate=int(time.time()))
def guid():return ifcopenshell.guid.new()
def pt(x=0,y=0,z=None):return e('IfcCartesianPoint',Coordinates=(float(x),float(y)) if z is None else (float(x),float(y),float(z)))
zdir=e('IfcDirection',DirectionRatios=(0.,0.,1.));xdir=e('IfcDirection',DirectionRatios=(1.,0.,0.));axis=e('IfcAxis2Placement3D',Location=pt(0,0,0),Axis=zdir,RefDirection=xdir)
ctx=e('IfcGeometricRepresentationContext',ContextIdentifier='Model',ContextType='Model',CoordinateSpaceDimension=3,Precision=1e-5,WorldCoordinateSystem=axis,TrueNorth=e('IfcDirection',DirectionRatios=(0.,1.)))
unit=e('IfcUnitAssignment',Units=[e('IfcSIUnit',UnitType='LENGTHUNIT',Name='METRE'),e('IfcSIUnit',UnitType='AREAUNIT',Name='SQUARE_METRE'),e('IfcSIUnit',UnitType='VOLUMEUNIT',Name='CUBIC_METRE'),e('IfcSIUnit',UnitType='PLANEANGLEUNIT',Name='RADIAN')])
project=e('IfcProject',GlobalId=guid(),OwnerHistory=hist,Name='Obor V09 - Archicad 26',RepresentationContexts=[ctx],UnitsInContext=unit)
placement=None
site=e('IfcSite',GlobalId=guid(),OwnerHistory=hist,Name='Obor',ObjectPlacement=e('IfcLocalPlacement',RelativePlacement=axis),CompositionType='ELEMENT');building=e('IfcBuilding',GlobalId=guid(),OwnerHistory=hist,Name='Model urban - volumetrie',ObjectPlacement=e('IfcLocalPlacement',RelativePlacement=axis),CompositionType='ELEMENT');storey=e('IfcBuildingStorey',GlobalId=guid(),OwnerHistory=hist,Name='Context urban',ObjectPlacement=e('IfcLocalPlacement',RelativePlacement=axis),CompositionType='ELEMENT',Elevation=0.)
for parent,child in [(project,site),(site,building),(building,storey)]:e('IfcRelAggregates',GlobalId=guid(),OwnerHistory=hist,RelatingObject=parent,RelatedObjects=[child])
contained=[];groups={};layers={}
def style(name,rgb):
 col=e('IfcColourRgb',Name=name,Red=float(rgb[0]),Green=float(rgb[1]),Blue=float(rgb[2]));rend=e('IfcSurfaceStyleRendering',SurfaceColour=col,Transparency=0.,ReflectanceMethod='NOTDEFINED');ss=e('IfcSurfaceStyle',Name=name,Side='BOTH',Styles=[rend]);return e('IfcPresentationStyleAssignment',Styles=[ss])
white=style('Cladiri albe',(1.,1.,1.));green=style('Suprafete vegetate',(.58,.74,.37));park=style('Parcuri - perimetre',(.77,.86,.63));tree=style('Coroane simbolice',(.39,.60,.27));trunk=style('Trunchi simbolic',(.45,.40,.31));red=style('Limita interventie',(.70,.24,.20));gray=style('Limita studiu',(.42,.49,.43))
def styled(item,sty):e('IfcStyledItem',Item=item,Styles=[sty]);return item
def localcurve(coords):return e('IfcPolyline',Points=[pt(x-626950,y-324600) for x,y,*_ in coords])
def extrusion(poly,h,sty,z=0):
 poly=poly.simplify(.001,preserve_topology=False)
 if poly.geom_type!='Polygon':raise ValueError('Non-polygon after 1mm cleanup')
 poly=orient(poly,sign=1.);outer=localcurve(poly.exterior.coords)
 if poly.interiors:pr=e('IfcArbitraryProfileDefWithVoids',ProfileType='AREA',OuterCurve=outer,InnerCurves=[localcurve(r.coords) for r in poly.interiors])
 else:pr=e('IfcArbitraryClosedProfileDef',ProfileType='AREA',OuterCurve=outer)
 ax=axis if not z else e('IfcAxis2Placement3D',Location=pt(0,0,z),Axis=zdir,RefDirection=xdir)
 return styled(e('IfcExtrudedAreaSolid',SweptArea=pr,Position=ax,ExtrudedDirection=zdir,Depth=float(h)),sty)
def props(ob,values):
 ps=[]
 for k,v in values.items():ps.append(e('IfcPropertySingleValue',Name=k,NominalValue=e('IfcReal',float(v)) if isinstance(v,(float,int)) else e('IfcText',str(v))))
 p=e('IfcPropertySet',GlobalId=guid(),OwnerHistory=hist,Name='Obor_Metadata',HasProperties=ps);e('IfcRelDefinesByProperties',GlobalId=guid(),OwnerHistory=hist,RelatedObjects=[ob],RelatingPropertyDefinition=p)
def product(name,items,category,rep_type='SweptSolid',placement_override=None,metadata=None):
 rep=e('IfcShapeRepresentation',ContextOfItems=ctx,RepresentationIdentifier='Body',RepresentationType=rep_type,Items=items);definition=e('IfcProductDefinitionShape',Representations=[rep]);ob=e('IfcBuildingElementProxy',GlobalId=guid(),OwnerHistory=hist,Name=name,ObjectType=category,ObjectPlacement=placement_override or e('IfcLocalPlacement',RelativePlacement=axis),Representation=definition,CompositionType='ELEMENT');contained.append(ob);groups.setdefault(category,[]).append(ob);layers.setdefault(category,[]).append(rep)
 if metadata:props(ob,metadata)
 return ob
props(project,{'Nota':'Studiu școlar V09; geometrie DWG. Înălțimi documentate OSM sau estimate explicit. Fără arbori / analiză accesibilitate.','Source_CRS':'EPSG:3844 Stereo70 XY','Model_Origin_Easting_m':M['summary']['origin_stereo70'][0],'Model_Origin_Northing_m':M['summary']['origin_stereo70'][1],'GridNorth':'Model +Y; nordul grilei','OSM_Attribution':'Copyright OpenStreetMap contributors, ODbL, https://www.openstreetmap.org/copyright'})
for v in M['volumes']:
 p=shape(v['geometry']);metadata={k:v[k] for k in ['building_id','height_m','base_m','status','method','confidence','osm_id','source_geometry','height_source_url'] if k in v}
 if v.get('levels') is not None:metadata['OSM_levels']=v['levels']
 metadata['in_study']='yes' if v['in_study'] else 'context'
 product(v['id'],[extrusion(p,v['height_m']-v['base_m'],white,v['base_m'])],'01_Cladiri_studiu' if v['in_study'] else '02_Cladiri_context',metadata=metadata)
colors={'Parcuri':(.13,.33,.23),'Scuaruri':(.20,.48,.33),'Fâșii plantate':(.34,.53,.28),'Spații verzi aferente locuințelor':(.39,.56,.48)}
for v in M['greens']:
 st=style(v['categorie'],colors[v['categorie']]);product(v['id'],[extrusion(shape(v['geometry']),.035,st,.04)],'VERDE_'+v['categorie'],metadata={'Categorie':v['categorie'],'Suprafata_m2':v['area_m2'],'Sursa':'Clasificare beneficiar V06'})
for key,cat,sty in [('study','Limita_studiu',gray),('site','Limita_interventie',red)]:
 from shapely.geometry import LineString
 items=[];coords=M[key]['coordinates'][0]
 for a,b in zip(coords,coords[1:]):
  if math.dist(a,b)<.1:continue
  items.append(extrusion(LineString([a,b]).buffer(.20,cap_style=2),.05,sty,.10))
 product(cat,items,cat)
rels=[e('IfcRelContainedInSpatialStructure',GlobalId=guid(),OwnerHistory=hist,RelatedElements=contained,RelatingStructure=storey)]
for name,obs in groups.items():
 group=e('IfcGroup',GlobalId=guid(),OwnerHistory=hist,Name=name);e('IfcRelAssignsToGroup',GlobalId=guid(),OwnerHistory=hist,RelatedObjects=obs,RelatingGroup=group);e('IfcPresentationLayerAssignment',Name=name,AssignedItems=layers[name])
F.header.file_description.description=('ViewDefinition [CoordinationView_V2.0]',);F.header.file_name.name='Obor_Volumetrie_V09_IFC2x3.ifc';F.write(O+'/Obor_Volumetrie_V09_IFC2x3.ifc');print('IFC exported',len(contained),'objects',flush=True)
