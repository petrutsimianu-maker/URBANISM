import os,json,sys,math
os.environ['MPLCONFIGDIR']='/tmp/mpl-obor-plan'
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from PIL import Image
O=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));S=json.load(open(O+'/Rezumat_V09.json'));img=Image.open(O+'/Axonometrie_modele_V09.png').convert('RGB')
plt.rcParams.update({'font.family':'DejaVu Sans','pdf.fonttype':42,'svg.fonttype':'none'})
f=plt.figure(figsize=(420/25.4,297/25.4),facecolor='white');ax=f.add_axes([.025,.176,.748,.675]);ax.imshow(img);ax.axis('off')
f.text(.043,.951,'OBOR / BUCUREȘTI',fontsize=10,weight='bold',color='#355e40');f.text(.043,.909,'Spații verzi și fond construit',fontsize=26,color='#283e30');f.text(.043,.875,'AXONOMETRIE VOLUMETRICĂ / ZONA OBOR, BUCUREȘTI / SITUAȚIA EXISTENTĂ CARTOGRAFIATĂ',fontsize=8,color='#6e7b71');f.text(.956,.913,'09',ha='right',fontsize=28,color='#a8b49c')
f.lines.append(plt.Line2D([.778,.778],[.175,.83],transform=f.transFigure,color='#dce2d6',lw=.7));x=.801
f.text(x,.813,'VOLUMETRIE ȘI VERDE',fontsize=9.3,weight='bold',color='#283e30')
f.text(x,.774,'2 467',fontsize=25,color='#315c39');f.text(x,.750,'clădiri în zona de studiu',fontsize=8,color='#68786b');f.text(x,.709,'349,18 ha',fontsize=19,color='#315c39');f.text(x,.685,'suprafața zonei de studiu',fontsize=8,color='#68786b')
f.text(x,.642,'LEGENDĂ',fontsize=9,weight='bold',color='#283e30')
items=[('Parcuri','#21543b'),('Scuaruri','#337a54'),('Fâșii plantate','#578747'),('Spații aferente locuințelor','#638f7b')]
for j,(label,col) in enumerate(items):
 y=.611-j*.032;f.patches.append(Rectangle((x,y-.002),.012,.011,transform=f.transFigure,fc=col,ec='none'));f.text(x+.019,y,label,fontsize=7.3,color='#4b5d4e')
f.patches.append(Rectangle((x,.464),.012,.011,transform=f.transFigure,fc='white',ec='#636d66',lw=.6));f.text(x+.019,.466,'Clădiri · volume albe',fontsize=7.3,color='#4b5d4e')
for j,(label,col) in enumerate([('Limita zonei de studiu','#425c4c'),('Limita intervenției','#a3453b')]):
 y=.432-j*.030;f.lines.append(plt.Line2D([x,x+.026],[y,y],transform=f.transFigure,color=col,lw=.9,ls='--'));f.text(x+.033,y-.004,label,fontsize=7.1,color='#4b5d4e')
f.text(x,.352,'ÎNĂLȚIMI UTILIZATE',fontsize=8.4,weight='bold',color='#283e30')
f.text(x,.325,'1  ·  înălțime declarată OSM\n446  ·  niveluri OSM × 3 m\n2 020  ·  estimări morfologice',va='top',fontsize=7.8,linespacing=1.55,color='#4b5d4e')
# North follows projected model +Y; annotation in points avoids figure aspect distortion.
ang=math.radians(26);el=math.radians(38);dx=math.sin(ang);dy=math.cos(ang)*math.sin(el);norm=math.hypot(dx,dy);delta=(24*dx/norm,24*dy/norm)
ax.annotate('',xy=(.855,.205),xytext=(-delta[0],-delta[1]),xycoords=f.transFigure,textcoords='offset points',arrowprops={'arrowstyle':'-|>','color':'#355e40','lw':1},annotation_clip=False)
f.text(.864,.216,'N',fontsize=9,color='#355e40');f.text(x,.181,'Nordul grilei · proiecție paralelă',fontsize=6.5,color='#68786b')
f.text(.043,.141,'Clădiri albe, fără diferențieri funcționale. Spații verzi aprobate V06, fără arbori, degradeuri de accesibilitate sau marcaje roșii.',fontsize=7.4,color='#53664f')
f.lines.append(plt.Line2D([.043,.956],[.117,.117],transform=f.transFigure,color='#dce2d6',lw=.7))
f.text(.043,.094,'METODĂ: amprente DWG; înălțimi OSM unde există, niveluri convertite la 3 m și estimări locale explicite. Fără exagerare verticală.',fontsize=7,color='#68786b')
f.text(.043,.074,'Înălțimile declarate în OSM nu sunt măsurători verificate independent. Tabelul editabil distinge sursele, estimările și incertitudinea.',fontsize=7,color='#68786b')
f.text(.043,.054,'120 de contururi verzi · 138 638,30 m². SV-027 exclus; SV-029 păstrat la Parcuri. Context exterior discret; modelul nu este un releveu.',fontsize=7,color='#68786b')
f.text(.043,.032,'Surse: DWG/PDF beneficiar + © OpenStreetMap contributors (extras 17.10.2026, ODbL) + clasificare V06. Model și randare Blender 4.3.2.',fontsize=6.6,color='#83907e');f.text(.956,.032,'19.10.2026 · A3 PEISAJ',ha='right',fontsize=6.8,color='#83907e')
f.savefig(O+'/Obor_Axonometrie_V09_A3.pdf',dpi=300);f.savefig(O+'/Obor_Axonometrie_V09_A3.png',dpi=300);f.savefig(O+'/Obor_Axonometrie_V09_A3.svg',dpi=300);f.savefig(O+'/preview.png',dpi=110);plt.close(f)
print('A3 composed',flush=True)
