import os
import sys,os,json,subprocess,csv,xml.etree.ElementTree as ET
sys.path.insert(0,'/tmp/obor-ifc')
from shapely.geometry import shape,mapping
from shapely.affinity import translate
import openpyxl
O=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));M=json.load(open(O+'/Model_V09.json'));tx,ty=json.load(open(O+'/inputs/osm_registration.json'))['translation_osm_to_cad'];gpkg=O+'/Obor_Model_V09.gpkg'
if os.path.exists(gpkg):os.unlink(gpkg)
layers={}
for name,rows,columns in [('cladiri_3d',M['volumes'],['id','building_id','height_m','base_m','levels','status','method','confidence','osm_id','height_source_url','in_study']),('spatii_verzi',M['greens'],['id','categorie','area_m2'])]:
 feats=[]
 for r in rows:feats.append({'type':'Feature','geometry':mapping(translate(shape(r['geometry']),-tx,-ty)),'properties':{k:r.get(k) for k in columns}})
 layers[name]=feats
layers['limite']=[{'type':'Feature','geometry':mapping(translate(shape(M[k]),-tx,-ty)),'properties':{'tip':k}} for k in ['study','site']]
for i,(name,feats) in enumerate(layers.items()):
 path=O+'/'+name+'.geojson';json.dump({'type':'FeatureCollection','crs':{'type':'name','properties':{'name':'urn:ogc:def:crs:EPSG::3844'}},'features':feats},open(path,'w'),ensure_ascii=False)
 subprocess.run(['ogr2ogr','-f','GPKG']+(['-update'] if i else [])+[gpkg,path,'-nln',name,'-a_srs','EPSG:3844'],check=True)
# Spreadsheet mirrors all model-body metadata, including the context classification.
wb=openpyxl.Workbook();ws=wb.active;ws.title='Inaltimi volume';headers=['id','building_id','in_study','area_m2','height_m','base_m','levels','status','method','confidence','osm_id','height_source_url'];ws.append(headers)
for r in M['volumes']:ws.append([r.get(k) for k in headers])
ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
for j in range(1,len(headers)+1):ws.column_dimensions[openpyxl.utils.get_column_letter(j)].width=18 if j not in [9,12] else 65
summary=wb.create_sheet('Rezumat');summary.append(['Indicator','Valoare'])
for k,v in M['summary'].items():summary.append([k,str(v) if isinstance(v,(dict,list)) else v])
summary.column_dimensions['A'].width=45;summary.column_dimensions['B'].width=80;wb.save(O+'/Inaltimi_cladiri_V09.xlsx')
# Lightweight relative-path QGIS project: neutral outlines and categorized green surfaces.
q=ET.Element('qgis',{'version':'3.34.0','projectname':'Obor V09 — control GIS volumetrie'});ET.SubElement(q,'title').text='Obor V09 — volumetrie / înălțimi';crs=ET.SubElement(q,'projectCrs');sr=ET.SubElement(crs,'spatialrefsys');ET.SubElement(sr,'authid').text='EPSG:3844';ET.SubElement(sr,'description').text='Pulkovo 1942(58) / Stereo70';ET.SubElement(sr,'projectionacronym').text='sterea';ET.SubElement(sr,'geographicflag').text='false'
tree=ET.SubElement(q,'layer-tree-group',{'name':'','checked':'Qt::Checked','expanded':'1'});pls=ET.SubElement(q,'projectlayers')
for name,color in [('limite','98,114,100,0'),('cladiri_3d','255,255,255,255'),('spatii_verzi','40,104,71,255')]:
 source='./Obor_Model_V09.gpkg|layername='+name;lid=name+'_v09';ET.SubElement(tree,'layer-tree-layer',{'name':name,'id':lid,'source':source,'providerKey':'ogr','checked':'Qt::Checked','expanded':'1'});ml=ET.SubElement(pls,'maplayer',{'type':'vector','geometry':'Polygon'});ET.SubElement(ml,'id').text=lid;ET.SubElement(ml,'datasource').text=source;ET.SubElement(ml,'layername').text=name;ET.SubElement(ml,'provider').text='ogr';srs=ET.SubElement(ml,'srs');srs.append(ET.fromstring(ET.tostring(sr)))
 if name=='spatii_verzi':
  render=ET.SubElement(ml,'renderer-v2',{'type':'categorizedSymbol','attr':'categorie','symbollevels':'0'});cats=ET.SubElement(render,'categories');symbols=ET.SubElement(render,'symbols');entries=[('Parcuri','33,84,59,255'),('Scuaruri','51,122,84,255'),('Fâșii plantate','87,135,71,255'),('Spații verzi aferente locuințelor','99,143,123,255')]
  for i,(label,col) in enumerate(entries):ET.SubElement(cats,'category',{'symbol':str(i),'value':label,'label':label,'render':'true'})
 else:render=ET.SubElement(ml,'renderer-v2',{'type':'singleSymbol','symbollevels':'0'});symbols=ET.SubElement(render,'symbols');entries=[('',color)]
 for i,(label,col) in enumerate(entries):
  symbol=ET.SubElement(symbols,'symbol',{'name':str(i),'type':'fill','alpha':'1'});l=ET.SubElement(symbol,'layer',{'class':'SimpleFill','enabled':'1','locked':'0','pass':'0'})
  for k,v in {'color':col,'outline_color':'105,118,110,255','outline_width':'.15' if name!='limite' else '.4','style':'no' if name=='limite' else 'solid'}.items():ET.SubElement(l,'prop',{'k':k,'v':v})
mc=ET.SubElement(q,'mapcanvas');ET.SubElement(mc,'units').text='meters';ext=ET.SubElement(mc,'extent');bounds=translate(shape(M['study']),-tx,-ty).bounds
for k,v in zip(['xmin','ymin','xmax','ymax'],bounds):ET.SubElement(ext,k).text=str(v)
ET.indent(q);ET.ElementTree(q).write(O+'/Obor_Model_V09.qgs',encoding='utf-8',xml_declaration=True)
print('GIS and spreadsheet exported',flush=True)
