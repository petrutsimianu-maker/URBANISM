import sys,json,collections,os,math
sys.path.insert(0,'/workspace/.urbanism-python')
import ifcopenshell,ifcopenshell.util.placement,ifcopenshell.util.unit,ifcopenshell.geom,numpy as np
from shapely.geometry import shape,Polygon,LineString
from shapely.ops import unary_union,polygonize_full
O='/workspace/Obor_Drumuri_V11';os.makedirs(O,exist_ok=True)
D=json.load(open('/workspace/URBANISM-v02/cad_geometry.json'));E=[r for r in D if r['layer']=='Street_line'];print('Street_line',len(E),'closed',sum(r['closed'] for r in E),'types',collections.Counter(r.get('type') for r in E),flush=True)
lines=[];closed=[]
for i,r in enumerate(E):
 pts=[p[:2] for p in r['points']]
 if len(pts)<2:continue
 if r['closed']:
  if pts[0]!=pts[-1]:pts.append(pts[0])
  p=Polygon(pts)
  if p.is_valid and p.area>1:closed.append((i,p))
 lines.append(LineString(pts))
M=json.load(open('/workspace/URBANISM-v02/model_data.json'));st=shape(M['study']);region=st.buffer(100);ll=[l for l in lines if l.intersects(region)];merged=unary_union(ll);polys,cuts,dangles,invalid=polygonize_full(merged);print('polygonize raw',len(polys.geoms),'cuts',len(cuts.geoms),'dangles',len(dangles.geoms),'invalid',len(invalid.geoms),flush=True)
json.dump({'lines':[list(l.coords) for l in ll],'closed':[{'idx':i,'geometry':p.__geo_interface__} for i,p in closed if p.intersects(region)],'polygonized':[p.__geo_interface__ for p in polys.geoms],'dangles':[l.__geo_interface__ for l in dangles.geoms]},open(O+'/Street_audit_raw.json','w'))
f=ifcopenshell.open('/workspace/attachments/e2962628-06bb-4954-bec1-7021b206dda0/261019 Obor_Volumetrie_monumente.ifc');print('IFC',f.schema,'units m/iu',ifcopenshell.util.unit.calculate_unit_scale(f),'class_counts',collections.Counter(p.is_a() for p in f.by_type('IfcProduct')),flush=True)
for p in f.by_type('IfcBuildingElementProxy')[:5]:print('sample',p.Name,ifcopenshell.util.placement.get_local_placement(p.ObjectPlacement).tolist(),flush=True)
settings=ifcopenshell.geom.settings();settings.set(settings.USE_WORLD_COORDS,True);it=ifcopenshell.geom.iterator(settings,f,4);cache=[];bounds=[]
if it.initialize():
 while True:
  ob=it.get();v=np.array(ob.geometry.verts).reshape(-1,3);faces=np.array(ob.geometry.faces).reshape(-1,3);p=f.by_guid(ob.guid);lo=v.min(0);hi=v.max(0);materials=[]
  for mat in ob.geometry.materials:
   try:rgb=list(mat.diffuse)
   except Exception:rgb=[.9,.9,.9]
   materials.append({'name':mat.name,'rgb':rgb})
  # Preserve full reference triangles for control views; do not regenerate geometry from the earlier model.
  cache.append({'guid':ob.guid,'name':p.Name,'ifc_type':p.is_a(),'min':lo.tolist(),'max':hi.tolist(),'vertices':v.tolist(),'faces':faces.tolist(),'material_ids':list(ob.geometry.material_ids),'materials':materials});bounds.append([lo.tolist(),hi.tolist()])
  if not it.next():break
json.dump(cache,open(O+'/Reference_geometry_cache.json','w'));mins=np.min([b[0] for b in bounds],0);maxs=np.max([b[1] for b in bounds],0);print('IFC objects with geometry',len(cache),'bounds',mins,maxs,flush=True)
print('zmin common',collections.Counter(round(r['min'][2],3) for r in cache).most_common(12),flush=True)
print('zmax flat common',collections.Counter(round(r['max'][2],3) for r in cache if r['max'][2]-r['min'][2]<.5).most_common(12),flush=True)
