import sys,json,time,os
sys.path.insert(0,'/workspace/.urbanism-python')
import ifcopenshell,ifcopenshell.guid,shapely
from shapely.geometry import shape
from shapely.geometry.polygon import orient
O='/workspace/Obor_Drumuri_V11';R=json.load(open(O+'/Drumuri_V11.json'));f=ifcopenshell.file(schema='IFC2X3');e=f.create_entity
person=e('IfcPerson',FamilyName='URBANISM');org=e('IfcOrganization',Name='Studiu Obor');actor=e('IfcPersonAndOrganization',ThePerson=person,TheOrganization=org);app=e('IfcApplication',ApplicationDeveloper=org,Version='V11',ApplicationFullName='Obor Street_line road network',ApplicationIdentifier='OBOR_ROADS');hist=e('IfcOwnerHistory',OwningUser=actor,OwningApplication=app,ChangeAction='ADDED',CreationDate=int(time.time()))
def guid():return ifcopenshell.guid.new()
def pt(x=0,y=0,z=None):return e('IfcCartesianPoint',Coordinates=(float(x),float(y)) if z is None else (float(x),float(y),float(z)))
zdir=e('IfcDirection',DirectionRatios=(0.,0.,1.));xdir=e('IfcDirection',DirectionRatios=(1.,0.,0.));axis=e('IfcAxis2Placement3D',Location=pt(0,0,0),Axis=zdir,RefDirection=xdir);ctx=e('IfcGeometricRepresentationContext',ContextIdentifier='Model',ContextType='Model',CoordinateSpaceDimension=3,Precision=1e-6,WorldCoordinateSystem=axis,TrueNorth=e('IfcDirection',DirectionRatios=(0.,1.)))
units=e('IfcUnitAssignment',Units=[e('IfcSIUnit',UnitType='LENGTHUNIT',Name='METRE'),e('IfcSIUnit',UnitType='AREAUNIT',Name='SQUARE_METRE'),e('IfcSIUnit',UnitType='VOLUMEUNIT',Name='CUBIC_METRE')]);project=e('IfcProject',GlobalId=guid(),OwnerHistory=hist,Name='Obor V11 - numai circulatii Street_line',RepresentationContexts=[ctx],UnitsInContext=units)
site=e('IfcSite',GlobalId=guid(),OwnerHistory=hist,Name='Obor - coordonate model de referinta',ObjectPlacement=e('IfcLocalPlacement',RelativePlacement=axis),CompositionType='ELEMENT');building=e('IfcBuilding',GlobalId=guid(),OwnerHistory=hist,Name='Retea de circulatii',ObjectPlacement=e('IfcLocalPlacement',RelativePlacement=axis),CompositionType='ELEMENT');storey=e('IfcBuildingStorey',GlobalId=guid(),OwnerHistory=hist,Name='Teren Z0 - drumuri',ObjectPlacement=e('IfcLocalPlacement',RelativePlacement=axis),CompositionType='ELEMENT',Elevation=0.)
for parent,child in [(project,site),(site,building),(building,storey)]:e('IfcRelAggregates',GlobalId=guid(),OwnerHistory=hist,RelatingObject=parent,RelatedObjects=[child])
colour=e('IfcColourRgb',Name='Gri deschis circulatii',Red=225/255,Green=228/255,Blue=226/255);render=e('IfcSurfaceStyleRendering',SurfaceColour=colour,Transparency=0.,ReflectanceMethod='NOTDEFINED');style=e('IfcPresentationStyleAssignment',Styles=[e('IfcSurfaceStyle',Name='URB_DRUMURI_STREET_LINE',Side='BOTH',Styles=[render])]);products=[];reps=[]
def props(ob,values):
 values={k:v for k,v in values.items() if v is not None};properties=[]
 for k,v in values.items():properties.append(e('IfcPropertySingleValue',Name=k,NominalValue=e('IfcReal',float(v)) if isinstance(v,(int,float)) else e('IfcText',str(v))))
 ps=e('IfcPropertySet',GlobalId=guid(),OwnerHistory=hist,Name='Obor_Roads_Metadata',HasProperties=properties);e('IfcRelDefinesByProperties',GlobalId=guid(),OwnerHistory=hist,RelatedObjects=[ob],RelatingPropertyDefinition=ps)
reg=json.load(open(O+'/Aliniere_IFC_V11.json'));props(project,{'Reference_IFC':'261019 Obor_Volumetrie_monumente.ifc','Coordinates':'Metre; coordonate mondiale model referinta, unitati convertite din mm','CAD_to_model_X_m':reg['CAD_to_reference_m'][0],'CAD_to_model_Y_m':reg['CAD_to_reference_m'][1],'Notes':'Numai drumuri. Geometrie Street_line reparata; latimi de completare OSM estimative. Nu este proiect de executie.','OSM':'Copyright OpenStreetMap contributors, ODbL, extras 17.10.2026; control API 25.10.2026'})
for r in R:
 p=shape(r['geometry_model'])
 if r['id']=='DR-014':p=p.simplify(.0001,preserve_topology=True)
 if r['id']=='DR-025':p=shapely.set_precision(p,.0001)
 p=orient(p,1)
 def curve(coords):return e('IfcPolyline',Points=[pt(x,y) for x,y,*_ in coords])
 outer=curve(p.exterior.coords)
 if p.interiors:profile=e('IfcArbitraryProfileDefWithVoids',ProfileType='AREA',OuterCurve=outer,InnerCurves=[curve(ring.coords) for ring in p.interiors])
 else:profile=e('IfcArbitraryClosedProfileDef',ProfileType='AREA',OuterCurve=outer)
 at=e('IfcAxis2Placement3D',Location=pt(0,0,r['base_m']),Axis=zdir,RefDirection=xdir);solid=e('IfcExtrudedAreaSolid',SweptArea=profile,Position=at,ExtrudedDirection=zdir,Depth=r['thickness_m']);e('IfcStyledItem',Item=solid,Styles=[style]);rep=e('IfcShapeRepresentation',ContextOfItems=ctx,RepresentationIdentifier='Body',RepresentationType='SweptSolid',Items=[solid]);definition=e('IfcProductDefinitionShape',Representations=[rep]);ob=e('IfcSlab',GlobalId=guid(),OwnerHistory=hist,Name=r['id'],Description='Circulatii / Street_line',ObjectType='URB_DRUMURI_STREET_LINE',ObjectPlacement=e('IfcLocalPlacement',RelativePlacement=axis),Representation=definition,Tag=r['id'],PredefinedType='FLOOR');products.append(ob);reps.append(rep);props(ob,{k:r[k] for k in ['area_m2','estimated_area_m2','status','source','layer','base_m','top_m','thickness_m','sector_grid']})
e('IfcRelContainedInSpatialStructure',GlobalId=guid(),OwnerHistory=hist,RelatedElements=products,RelatingStructure=storey);group=e('IfcGroup',GlobalId=guid(),OwnerHistory=hist,Name='URB_DRUMURI_STREET_LINE');e('IfcRelAssignsToGroup',GlobalId=guid(),OwnerHistory=hist,RelatedObjects=products,RelatingGroup=group);e('IfcPresentationLayerAssignment',Name='URB_DRUMURI_STREET_LINE',Description='Layer independent pentru toate circulatiile',AssignedItems=reps)
f.header.file_description.description=('ViewDefinition [CoordinationView_V2.0]',);f.header.file_name.name='Obor_Drumuri_V11_IFC2x3.ifc';f.write(O+'/Obor_Drumuri_V11_IFC2x3.ifc');print('Exported',len(products),'road slabs')
