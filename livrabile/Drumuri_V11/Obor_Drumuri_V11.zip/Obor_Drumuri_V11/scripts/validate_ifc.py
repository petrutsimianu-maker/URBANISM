import os,sys,json
sys.path.insert(0,'/workspace/.urbanism-python')
import ifcopenshell,ifcopenshell.geom,ifcopenshell.validate,numpy as np
O='/workspace/Obor_Drumuri_V11';f=ifcopenshell.open(O+'/Obor_Drumuri_V11_IFC2x3.ifc');R=json.load(open(O+'/Drumuri_V11.json'));expected={r['id']:r for r in R};logger=ifcopenshell.validate.json_logger();ifcopenshell.validate.validate(f,logger);assert not logger.statements,str(logger.statements[:3]);assert not f.by_type('IfcBuildingElementProxy');products=f.by_type('IfcSlab');assert len(products)==len(R)
layer=f.by_type('IfcPresentationLayerAssignment');assert len(layer)==1 and layer[0].Name=='URB_DRUMURI_STREET_LINE' and len(layer[0].AssignedItems)==len(R)
settings=ifcopenshell.geom.settings();settings.set(settings.USE_WORLD_COORDS,True);it=ifcopenshell.geom.iterator(settings,f,4);seen=set();toparea=0;areaerrors=[]
if it.initialize():
 while True:
  ob=it.get();p=f.by_guid(ob.guid);v=np.array(ob.geometry.verts).reshape(-1,3);faces=np.array(ob.geometry.faces).reshape(-1,3);assert abs(v[:,2].min()+.11)<1e-6 and abs(v[:,2].max()-.01)<1e-6
  top=faces[np.all(np.abs(v[faces,2]-.01)<1e-6,axis=1)];a=0
  for tri in top:
   q=v[tri];a+=abs(np.cross(q[1]-q[0],q[2]-q[0])[2])/2
  err=abs(a-expected[p.Name]['area_m2']);assert err<.02,(p.Name,a,expected[p.Name]['area_m2']);areaerrors.append(err);toparea+=a;seen.add(p.Name)
  if not it.next():break
print('Geometry count',len(seen),'/',len(expected),'missing',sorted(set(expected)-seen),flush=True)
json.dump(sorted(set(expected)-seen),open(O+'/Missing_geometry_debug.json','w'))
assert seen==set(expected)
result={'schema':f.schema,'schema_errors':0,'IfcSlab_count':len(products),'geometry_generated':len(seen),'only_road_geometry':True,'layer':layer[0].Name,'group':'URB_DRUMURI_STREET_LINE','unit':'metre','bottom_m':-.11,'top_m':.01,'thickness_m':.12,'surface_area_IFC_m2':toparea,'max_area_error_m2':max(areaerrors),'Archicad26_import_tested':False};json.dump(result,open(O+'/Verificare_IFC_V11.json','w'),indent=2);print(result,flush=True)
