import sys,json,os,csv,math
sys.path.insert(0,'/workspace/.urbanism-python')
import shapely,numpy as np
from shapely.geometry import shape,box,mapping,LineString,Polygon
from shapely.ops import unary_union
from shapely.affinity import translate
O='/workspace/Obor_Drumuri_V11';M=json.load(open(O+'/Roads_working_model.json'));road=shape(M['roads']);study=shape(M['study']);estimated=shape(M['estimated_road_parts']);G=json.load(open('/workspace/Obor_Plan2D_V06/Spatii_verzi_individuale.json'));green=unary_union([shape(r['geometry']) for r in G]);overlap=road.intersection(green)
# Existing V06 green is protected. Park overlaps are tiny perimeter differences; no internal park network was inferred.
road=road.difference(green);minx,miny,maxx,maxy=road.bounds;records=[];dropped=0
for x in range(math.floor(minx/300)*300,math.ceil(maxx/300)*300,300):
 for y in range(math.floor(miny/300)*300,math.ceil(maxy/300)*300,300):
  q=road.intersection(box(x,y,x+300,y+300))
  for p in [q] if q.geom_type=='Polygon' else [p for p in getattr(q,'geoms',[]) if p.geom_type=='Polygon']:
   if p.area<.25:dropped+=p.area;continue
   p=shapely.make_valid(p)
   if p.geom_type!='Polygon':continue
   a=p.intersection(estimated).area;r={'id':'DR-'+str(len(records)+1).zfill(3),'geometry_cad':mapping(p),'geometry_model':mapping(translate(p,*M['registration']['CAD_to_reference_m'])),'area_m2':p.area,'estimated_area_m2':a,'status':'completare estimativă OSM + limite CAD' if a>.1 else 'Street_line; topologie reparată','source':'DWG Street_line / OpenStreetMap 17.10.2026','layer':'URB_DRUMURI_STREET_LINE','base_m':-.11,'top_m':.01,'thickness_m':.12,'sector_grid':f'{x}_{y}'};records.append(r)
union=unary_union([shape(r['geometry_cad']) for r in records]);assert abs(sum(r['area_m2'] for r in records)-union.area)<.02;assert union.difference(study).area<.001;assert union.intersection(shape(M['buildings'])).area<.001;assert union.intersection(green).area<.001
M['roads']=mapping(union);M['green_control']=mapping(green);M['green_overlap_removed']=mapping(overlap);M['summary'].update(final_roads_area_m2=union.area,final_roads_percent=union.area/study.area*100,green_overlap_removed_m2=overlap.area,minor_slivers_removed_m2=dropped,object_count=len(records),partition_grid_m=300,final_estimated_area_m2=sum(r['estimated_area_m2'] for r in records),green_reference_source='Inventar V06; IFC-ul de referință conține explicit numai SV-113');json.dump(M,open(O+'/Roads_working_model.json','w'),ensure_ascii=False);json.dump(records,open(O+'/Drumuri_V11.json','w'),ensure_ascii=False);json.dump(M['summary'],open(O+'/Rezumat_V11.json','w'),ensure_ascii=False,indent=2)
with open(O+'/Drumuri_V11.csv','w',encoding='utf-8-sig',newline='') as f:
 fields=['id','area_m2','estimated_area_m2','status','source','layer','base_m','top_m','thickness_m','sector_grid'];w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore',delimiter=';');w.writeheader();w.writerows(records)
# Full source registration statistics, including independent regions.
A=json.load(open(O+'/Reference_alignment_candidates.json'));d=np.array(A['median_offset_from_V09_local']);rows=[]
for p in A['pairs']:
 residual=float(np.linalg.norm(np.array(p['delta'])-d))
 if residual<.05:rows.append({'name':p['name'],'residual_m':residual,'reference_centroid':list(shape(p['reference_geometry']).centroid.coords)[0]})
region={}
for name,selector in [('Nord',lambda x,y:y>600),('Sud',lambda x,y:y< -600),('Vest',lambda x,y:x< -800),('Est',lambda x,y:x>700)]:
 selected=[p for p in rows if selector(*p['reference_centroid'])];region[name]={'matches':len(selected),'max_residual_m':max(p['residual_m'] for p in selected)}
json.dump({'CAD_to_reference_m':M['registration']['CAD_to_reference_m'],'offset_from_V09_local_m':d.tolist(),'robust_inliers':len(rows),'all_candidates':len(A['pairs']),'regions':region,'outliers':[p['name'] for p in A['pairs'] if np.linalg.norm(np.array(p['delta'])-d)>.05],'unit_reference_IFC':'millimetre; coordinates geometry converted to metres','unit_road_IFC':'metre','base_ground_m':0.,'road_top_m':.01,'road_base_m':-.11},open(O+'/Aliniere_IFC_V11.json','w'),indent=2)
# GIS absolute Stereo70 coordinates and separate line repairs.
otx,oty=json.load(open('/workspace/URBANISM-v02/osm_registration.json'))['translation_osm_to_cad'];features=[{'type':'Feature','geometry':mapping(translate(shape(r['geometry_cad']),-otx,-oty)),'properties':{k:v for k,v in r.items() if k not in ['geometry_cad','geometry_model']}} for r in records];json.dump({'type':'FeatureCollection','crs':{'type':'name','properties':{'name':'urn:ogc:def:crs:EPSG::3844'}},'features':features},open(O+'/Drumuri_V11_Stereo70.geojson','w'),ensure_ascii=False)
print(M['summary'],flush=True)
