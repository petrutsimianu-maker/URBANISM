import sys,json,math,collections,os
sys.path.insert(0,'/workspace/.urbanism-python');os.environ['MPLCONFIGDIR']='/tmp/mpl-roads'
import numpy as np,shapely,fitz
from shapely.geometry import shape,LineString,Polygon,Point,mapping
from shapely.ops import unary_union,polygonize_full,nearest_points
from scipy.spatial import cKDTree
O='/workspace/Obor_Drumuri_V11';M=json.load(open('/workspace/URBANISM-v02/model_data.json'));oldstudy=shape(M['study']);site=shape(M['site']);D=json.load(open('/workspace/URBANISM-v02/cad_geometry.json'));A=json.load(open(O+'/Street_audit_raw.json'));B=json.load(open(O+'/Reference_alignment_candidates.json'));offset=B['median_offset_from_V09_local'];dxc=-626950+offset[0];dyc=-324600+offset[1]
# Reconstruct exact current PDF border, sampling the original Bezier pieces.
pdf=fitz.open('/workspace/attachments/1879907b-4c38-4285-9364-6a7721de8468/Plan de bază.pdf');black=next(d for d in pdf[0].get_drawings() if d['color'] and max(d['color'])<.1 and len(d['items'])>50);tx,ty,scale=json.load(open('/workspace/URBANISM-v02/registration.json'))['transform'];pts=[]
for it in black['items']:
 if it[0]=='l':q=[it[1],it[2]]
 elif it[0]=='c':
  q=[]
  for t in np.linspace(0,1,15):q.append(tuple((1-t)**3*it[1][k]+3*(1-t)**2*t*it[2][k]+3*(1-t)*t*t*it[3][k]+t**3*it[4][k] for k in [0,1]))
 else:continue
 for p in q:
  xy=(tx+p[0]*scale,ty-p[1]*scale)
  if not pts or math.dist(xy,pts[-1])>.0001:pts.append(xy)
study=shapely.make_valid(Polygon(pts));assert study.geom_type=='Polygon' and abs(study.area/oldstudy.area-1)<.01
print('Current PDF area',study.area,'previous',oldstudy.area,'difference',study.symmetric_difference(oldstudy).area,flush=True)
# OSM supplementary geometry in the same CAD coordinate system.
OSM=json.load(open('/workspace/URBANISM-v02/osm/osm_projected.json'));otx,oty=json.load(open('/workspace/URBANISM-v02/osm_registration.json'))['translation_osm_to_cad'];road_osm=[];public_axes=[];rail=[];water=[]
width_default={'primary':15.,'primary_link':9.,'secondary':12.,'secondary_link':8.,'tertiary':9.,'tertiary_link':7.,'residential':6.,'living_street':5.,'unclassified':5.,'service':3.5,'pedestrian':3.,'footway':1.5,'path':1.25,'track':2.5,'steps':1.2}
for wid,w in OSM['ways'].items():
 tags=w.get('tags',{});coords=[(OSM['nodes'][n]['xy'][0]+otx,OSM['nodes'][n]['xy'][1]+oty) for n in w['nodes'] if n in OSM['nodes']]
 if len(coords)<2:continue
 line=LineString(coords)
 if not line.intersects(study.buffer(100)):continue
 if tags.get('railway')=='rail' and tags.get('bridge')!='yes' and tags.get('tunnel')!='yes':rail.append(line)
 h=tags.get('highway')
 if h not in width_default or tags.get('access') in ['no','private','customers']:continue
 half=width_default[h]
 # OSM explicit widths have priority; otherwise retain a conservative class-based corridor only for ambiguous gaps.
 try:
  width=float(tags.get('width','').replace('m','').strip());half=min(25,max(1,width/2))
 except Exception:pass
 road_osm.append({'id':wid,'line':line,'halfwidth':half,'tags':tags})
 if h in ['primary','secondary','tertiary','residential','living_street','unclassified','primary_link','secondary_link','tertiary_link']:public_axes.append(line)
axes=unary_union(public_axes);shapely.prepare(axes);axes_guard=axes.buffer(.65);shapely.prepare(axes_guard);osm_corridor=unary_union([r['line'].buffer(r['halfwidth'],cap_style=2,join_style=2) for r in road_osm]);rail_block=unary_union(rail).buffer(2.)
# Close minor discontinuities without crossing a mapped public street axis.
lines=[LineString(q) for q in A['lines']];network=unary_union(shapely.set_precision(np.array(lines,dtype=object),.02));repairs=[]
for tol in [.15,.5,1.5,3.,6.,10.,18.]:
 pieces=[p for p in getattr(network,'geoms',[network]) if p.geom_type=='LineString'];ends=collections.Counter(tuple(p.coords[k]) for p in pieces for k in [0,-1]);dangling=[k for k,v in ends.items() if v==1];kdt=cKDTree(dangling);line_tree=shapely.STRtree(pieces);proposed=[];used=set()
 for i,xy in enumerate(dangling):
  if i in used:continue
  pt=Point(xy);ds,js=kdt.query(xy,k=min(6,len(dangling)),distance_upper_bound=tol)
  candidates=[]
  for dist,j in zip(np.atleast_1d(ds),np.atleast_1d(js)):
   if not np.isfinite(dist) or j==i or j in used or dist<.001:continue
   candidates.append((float(dist),Point(dangling[j]),int(j)))
  for j in line_tree.query(pt,predicate='dwithin',distance=tol):
   line=pieces[int(j)]
   if line.distance(pt)<.001:continue
   q=nearest_points(pt,line)[1];dist=pt.distance(q)
   if dist>.001:candidates.append((dist,q,None))
  candidates.sort(key=lambda z:z[0])
  for dist,q,j in candidates:
   seg=LineString([pt,q]);mid=seg.interpolate(.5,normalized=True)
   if dist>.3 and axes_guard.intersects(seg):continue
   # Reject straight closure across a rail corridor as well.
   if dist>1 and seg.intersects(rail_block):continue
   proposed.append(seg);used.add(i)
   if j is not None:used.add(j)
   repairs.append({'tolerance_m':tol,'length_m':seg.length,'geometry':mapping(seg),'method':'închidere locală Street_line; fără traversarea axei publice OSM'})
   break
 if proposed:network=unary_union([network]+proposed)
polys,cuts,dangles,invalid=polygonize_full(network);islands=unary_union(list(polys.geoms));raw=study.difference(islands)
print('Repairs',len(repairs),'closed polygons',len(polys.geoms),'residual road candidate',raw.area,flush=True)
# Broad leftover fields are unverified land, not automatically roads. Preserve narrow inter-island corridors;
# in wide unresolved areas retain only support from public OSM axes, using bounded conventional widths.
widecore=raw.buffer(-22.,join_style=2).buffer(22.,join_style=2).intersection(raw)
road=raw.difference(widecore).union(raw.intersection(osm_corridor))
# Remove stray narrow bands along study edge where the source extends beyond the PDF boundary,
# only if remote from both an OSM road and real Street_line boundary.
# Protect the actual edited building footprints from the reference IFC.
built_ref=[]
for pair in B['pairs']:
 p=shape(pair['reference_geometry']);from shapely.affinity import translate
 built_ref.append(translate(p,-dxc,-dyc))
built=unary_union(built_ref)
road=shapely.make_valid(road).difference(built.buffer(.03));road=road.difference(rail_block.difference(osm_corridor))
# Filter tiny disconnected leftovers unless they have a verifiable route nearby.
parts=[road] if road.geom_type=='Polygon' else [p for p in getattr(road,'geoms',[]) if p.geom_type=='Polygon'];retained=[];removed=[]
for p in parts:
 if p.area<2:removed.append({'area_m2':p.area,'reason':'fragment <2m2'});continue
 if p.area<80 and p.distance(axes)>25:removed.append({'area_m2':p.area,'reason':'fragment izolat fără sprijin de rețea publică'});continue
 retained.append(p)
road=unary_union(retained).intersection(study);supported=road.intersection(osm_corridor);approx=road.intersection(widecore)
print('FINAL area',road.area,'pct',road.area/study.area*100,'parts',len(retained),'approx support',approx.area,'buildings overlap',road.intersection(built).area,flush=True)
json.dump({'study':mapping(study),'site':mapping(site),'roads':mapping(road),'islands':mapping(islands.intersection(study)),'wide_unverified':mapping(widecore.difference(road)),'estimated_road_parts':mapping(approx),'buildings':mapping(built),'osm_corridor':mapping(osm_corridor.intersection(study)),'registration':{'CAD_to_reference_m':[dxc,dyc],'offset_from_previous_local_m':offset},'repairs':repairs,'summary':{'study_area_m2':study.area,'roads_area_m2':road.area,'roads_percent':road.area/study.area*100,'raw_complement_area_m2':raw.area,'estimated_road_area_m2':approx.area,'repairs_count':len(repairs),'polygonized_islands':len(polys.geoms),'removed_fragments':removed,'boundary_difference_from_old_m2':study.symmetric_difference(oldstudy).area}},open(O+'/Roads_working_model.json','w'),ensure_ascii=False)
# diagnostic plot
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import PathPatch
from matplotlib.path import Path
from shapely.geometry.polygon import orient
fig,ax=plt.subplots(figsize=(13,12));ax.set_aspect('equal')
def draw(g,col,ec='none',lw=0):
 for p in [g] if g.geom_type=='Polygon' else [p for p in getattr(g,'geoms',[]) if p.geom_type=='Polygon']:
  p=orient(p,1);paths=[]
  for ring in [p.exterior]+list(p.interiors):q=list(ring.coords);paths.append(Path(q,[Path.MOVETO]+[Path.LINETO]*(len(q)-2)+[Path.CLOSEPOLY]))
  ax.add_patch(PathPatch(Path.make_compound_path(*paths),fc=col,ec=ec,lw=lw))
draw(road,'#c2cbc6');draw(approx,'#e3c78d');draw(built,'white','#7d8e85',.22);draw(study,'none','#a24840',.7);ax.set_xlim(study.bounds[0]-30,study.bounds[2]+30);ax.set_ylim(study.bounds[1]-30,study.bounds[3]+30);fig.savefig('/tmp/roads_repaired.png',dpi=125);plt.close(fig)
