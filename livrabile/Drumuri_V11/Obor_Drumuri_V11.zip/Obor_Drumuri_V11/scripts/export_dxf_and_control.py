import sys,os,json,csv,math,subprocess
sys.path.insert(0,'/workspace/.urbanism-python');os.environ['MPLCONFIGDIR']='/tmp/mpl-roads'
import numpy as np,shapely,ezdxf
from shapely.geometry import shape,mapping,LineString
from shapely.affinity import translate
from shapely.geometry.polygon import orient
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import PathPatch,Rectangle
from matplotlib.path import Path
from matplotlib.collections import LineCollection
from PIL import Image
O='/workspace/Obor_Drumuri_V11';M=json.load(open(O+'/Roads_working_model.json'));R=json.load(open(O+'/Drumuri_V11.json'));G=json.load(open('/workspace/Obor_Plan2D_V06/Spatii_verzi_individuale.json'));reg=M['registration']['CAD_to_reference_m'];origin=np.array([626950,324600]);study=shape(M['study']);roads=shape(M['roads']);buildings=shape(M['buildings']);greens=shape(M['green_control']);approx=roads.intersection(shape(M['estimated_road_parts']))
def parts(g):return [g] if g.geom_type=='Polygon' else [p for p in getattr(g,'geoms',[]) if p.geom_type=='Polygon']
# Standalone road-only DXF with separate estimated-sector contours and IDs.
d=ezdxf.new('R2013');d.units=6;d.layers.new('URB_DRUMURI_STREET_LINE').rgb=(225,228,226);d.layers.new('CONTROL_ESTIMARI').rgb=(180,133,62);d.layers.new('DRUMURI_CODURI').rgb=(85,100,90);ms=d.modelspace()
for r in R:
 p=orient(shape(r['geometry_model']),1);h=ms.add_hatch(dxfattribs={'layer':'URB_DRUMURI_STREET_LINE'});h.set_solid_fill(color=256)
 for j,ring in enumerate([p.exterior]+list(p.interiors)):
  pts=[(x,y) for x,y,*_ in ring.coords];h.paths.add_polyline_path(pts,is_closed=True,flags=1 if j==0 else 0);ms.add_lwpolyline(pts,close=True,dxfattribs={'layer':'URB_DRUMURI_STREET_LINE','elevation':.01})
 c=p.representative_point();ms.add_text(r['id'],dxfattribs={'height':4.,'layer':'DRUMURI_CODURI'}).set_placement((c.x,c.y))
 for poly in parts(p.intersection(translate(approx,*reg))):ms.add_lwpolyline(list(poly.exterior.coords),close=True,dxfattribs={'layer':'CONTROL_ESTIMARI','elevation':.01})
d.layers.get('CONTROL_ESTIMARI').off();d.layers.get('DRUMURI_CODURI').off();d.saveas(O+'/Obor_Drumuri_V11_metri.dxf');assert not ezdxf.readfile(O+'/Obor_Drumuri_V11_metri.dxf').audit().errors
# Editable GIS in Stereo70, plus explicit topology repairs.
otx,oty=json.load(open('/workspace/URBANISM-v02/osm_registration.json'))['translation_osm_to_cad'];repair_feats=[{'type':'Feature','geometry':mapping(translate(shape(r['geometry']),-otx,-oty)),'properties':{k:v for k,v in r.items() if k!='geometry'}} for r in M['repairs']];json.dump({'type':'FeatureCollection','crs':{'type':'name','properties':{'name':'urn:ogc:def:crs:EPSG::3844'}},'features':repair_feats},open(O+'/Reparatii_V11_Stereo70.geojson','w'),ensure_ascii=False)
gpkg=O+'/Obor_Drumuri_V11.gpkg'
if os.path.exists(gpkg):os.unlink(gpkg)
subprocess.run(['ogr2ogr','-f','GPKG',gpkg,O+'/Drumuri_V11_Stereo70.geojson','-nln','drumuri','-a_srs','EPSG:3844'],check=True)
subprocess.run(['ogr2ogr','-update',gpkg,O+'/Reparatii_V11_Stereo70.geojson','-nln','reparatii','-a_srs','EPSG:3844'],check=True)
# A3 control compositions, with a consistent legend and explicitly separated source inventories.
plt.rcParams.update({'font.family':'DejaVu Sans','pdf.fonttype':42,'svg.fonttype':'none'})
def ro(v,d=2):return f'{v:,.{d}f}'.replace(',',' ').replace('.',',')
def layout(title,subtitle,tag):
 f=plt.figure(figsize=(420/25.4,297/25.4),facecolor='white');f.text(.043,.950,'OBOR / BUCUREȘTI',fontsize=10,weight='bold',color='#355e40');f.text(.043,.909,title,fontsize=24,color='#283e30');f.text(.043,.875,subtitle,fontsize=8,color='#6e7b71');f.text(.956,.913,'11',ha='right',fontsize=28,color='#a8b49c');f.lines.append(plt.Line2D([.778,.778],[.175,.83],transform=f.transFigure,color='#dce2d6',lw=.7));x=.800
 f.text(x,.812,'REȚEAUA STREET_LINE',fontsize=10,weight='bold',color='#283e30');f.text(x,.770,ro(M['summary']['final_roads_area_m2']/10000)+' ha',fontsize=24,color='#315c39');f.text(x,.744,'suprafață reconstruită',fontsize=8,color='#68786b');f.text(x,.702,str(len(R))+' obiecte IFC',fontsize=18,color='#315c39');f.text(x,.676,'slaburi independente · 0,12 m',fontsize=8,color='#68786b');f.text(x,.628,'LEGENDĂ',fontsize=9,weight='bold',color='#283e30')
 items=[('Drumuri · gri deschis','#e1e4e2','none'),('Clădiri · model de referință','white','#798b80'),('Verde V06 · reper de control','#44724c','none')]
 if tag=='estimari':items.append(('Completări estimative','#d9b778','none'))
 for j,(label,col,ec) in enumerate(items):
  y=.594-j*.035;f.patches.append(Rectangle((x,y-.002),.012,.011,transform=f.transFigure,fc=col,ec=ec,lw=.5));f.text(x+.019,y,label,fontsize=7.2,color='#4b5d4e')
 for j,(label,col) in enumerate([('Limita studiului · PDF','#465e4c'),('Limita intervenției','#a3453b')]):
  y=.422-j*.032;f.lines.append(plt.Line2D([x,x+.026],[y,y],transform=f.transFigure,color=col,lw=.9,ls='--'));f.text(x+.033,y-.004,label,fontsize=7.1,color='#4b5d4e')
 f.text(x,.334,'CONTROL LA IMPORT',fontsize=8.5,weight='bold',color='#283e30');f.text(x,.307,'Layer / grup IFC independent:\nURB_DRUMURI_STREET_LINE\nUnități: metri\nTeren: Z = 0,00 m\nDrum: −0,11 … +0,01 m',va='top',fontsize=7.4,linespacing=1.5,color='#4b5d4e')
 f.lines.append(plt.Line2D([.043,.956],[.117,.117],transform=f.transFigure,color='#dce2d6',lw=.7));f.text(.043,.094,'METODĂ: diferență față de insulele Street_line; 207 reparații locale. În zone deschise, trasee OSM cu lățimi convenționale, marcate ca estimative.',fontsize=6.9,color='#68786b');f.text(.043,.074,'Drumurile sunt decupate la limita PDF și la clădiri; verdele V06 este protejat. Suprafețele de control din jur nu sunt incluse în IFC-ul de drumuri.',fontsize=6.9,color='#68786b');f.text(.043,.054,'Geometrie de urbanism orientativă, fără pante. Axonometria include modelul IFC de referință și verde V06 suplimentar, pentru verificarea suprapunerii.',fontsize=6.9,color='#68786b');f.text(.043,.032,'Surse: DWG/PDF + 261019 Obor_Volumetrie_monumente.ifc + © OpenStreetMap contributors, ODbL (17.10.2026; control API 25.10.2026).',fontsize=6.4,color='#83907e');f.text(.956,.032,'25.10.2026 · A3 PEISAJ',ha='right',fontsize=6.8,color='#83907e');return f

def patch(g,fc,ec,lw,ax,z=1):
 for p in parts(g):
  p=orient(p,1);paths=[]
  for ring in [p.exterior]+list(p.interiors):
   q=np.array(ring.coords)-origin;paths.append(Path(q,[Path.MOVETO]+[Path.LINETO]*(len(q)-2)+[Path.CLOSEPOLY]))
  ax.add_patch(PathPatch(Path.make_compound_path(*paths),fc=fc,ec=ec,lw=lw,zorder=z))
for diag in [False,True]:
 f=layout('Rețeaua de circulații · vedere în plan','CONTROL DE SUPRAPUNERE / MODEL DE REFERINȚĂ + STREET_LINE RECONSTRUIT','estimari' if diag else 'plan');ax=f.add_axes([.026,.174,.745,.672]);ax.axis('off');ax.set_aspect('equal');patch(roads,'#e1e4e2','none',0,ax)
 if diag:patch(approx,'#dfbd82','none',0,ax,z=2)
 for r in G:patch(shape(r['geometry']),r['culoare'],'none',0,ax,z=3)
 patch(buildings,'white','#92a098',.22,ax,z=4);patch(study,'none','#465e4c',.8,ax,z=5);patch(shape(M['site']),'none','#a3453b',.9,ax,z=5)
 bb=study.bounds;ax.set_xlim(bb[0]-origin[0]-40,bb[2]-origin[0]+40);ax.set_ylim(bb[1]-origin[1]-45,bb[3]-origin[1]+45);ax.annotate('',xy=(.08,.97),xytext=(.08,.88),xycoords='axes fraction',arrowprops={'arrowstyle':'-|>','color':'#355e40'});ax.text(.08,.98,'N',ha='center',transform=ax.transAxes,fontsize=9)
 name='Obor_Drumuri_V11_estimari_A3' if diag else 'Obor_Drumuri_V11_plan_A3';f.savefig(O+'/'+name+'.pdf');f.savefig(O+'/'+name+'.png',dpi=300);f.savefig('/tmp/'+name+'_preview.png',dpi=110);plt.close(f)
imgpath=O+'/Obor_Drumuri_V11_control_axon.png'
if os.path.exists(imgpath):
 f=layout('Rețeaua de circulații · axonometrie','CONTROL 3D / IFC DE REFERINȚĂ + DRUMURI + VERDE V06 SUPLIMENTAR','axon');ax=f.add_axes([.025,.176,.748,.675]);ax.imshow(Image.open(imgpath));ax.axis('off');f.savefig(O+'/Obor_Drumuri_V11_axon_A3.pdf',dpi=300);f.savefig(O+'/Obor_Drumuri_V11_axon_A3.png',dpi=300);f.savefig('/tmp/Obor_Drumuri_V11_axon_preview.png',dpi=110);plt.close(f)
print('DXF, GIS and control sheets exported',flush=True)
