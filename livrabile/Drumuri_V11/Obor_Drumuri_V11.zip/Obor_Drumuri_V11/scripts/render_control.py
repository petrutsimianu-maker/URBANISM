import bpy,json,math,os
from mathutils import Vector
from mathutils.geometry import tessellate_polygon
O='/workspace/Obor_Drumuri_V11';C=json.load(open(O+'/Reference_geometry_cache.json'));R=json.load(open(O+'/Drumuri_V11.json'));M=json.load(open(O+'/Roads_working_model.json'));G=json.load(open('/workspace/Obor_Plan2D_V06/Spatii_verzi_individuale.json'));dx,dy=M['registration']['CAD_to_reference_m']
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
for c in list(bpy.data.collections):
 if c.name!='Collection':bpy.data.collections.remove(c)
root=bpy.context.scene.collection;collections={}
for name in ['REFERENCE_IFC','URB_DRUMURI_STREET_LINE','VERDE_V06_CONTROL_SUPLIMENTAR','LIMITE_CONTROL']:
 c=bpy.data.collections.new(name);root.children.link(c);collections[name]=c
materials={}
def mat(name,rgb):
 key=(name,tuple(rgb))
 if key in materials:return materials[key]
 m=bpy.data.materials.new(name);m.diffuse_color=(*rgb,1);m.use_nodes=True;nt=m.node_tree;em=nt.nodes.new('ShaderNodeEmission');linear=tuple(v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in rgb);em.inputs['Color'].default_value=(*linear,1);nt.links.new(em.outputs['Emission'],nt.nodes.get('Material Output').inputs['Surface']);materials[key]=m;return m
white=mat('Conventie_control_cladiri_albe',(1,1,1));roadmat=mat('Gri_RGB_225_228_226',(225/255,228/255,226/255))
for r in C:
 if r['name'].startswith('Limita_'):continue
 mesh=bpy.data.meshes.new(r['name']);mesh.from_pydata(r['vertices'],[],r['faces']);mesh.update();ob=bpy.data.objects.new(r['name'],mesh);collections['REFERENCE_IFC'].objects.link(ob);ob['IFC_GUID']=r['guid'];ob['Source']='261019 Obor_Volumetrie_monumente.ifc'
 if r['name'].startswith('SV-'):mesh.materials.append(mat('Verde_IFC',(.39,.56,.48)))
 else:mesh.materials.append(white)
def polygon_mesh(name,geo,z,height,material,col):
 verts=[];loops=[]
 for ring in geo['coordinates']:
  coords=ring[:-1] if ring[0]==ring[-1] else ring;ids=[]
  for p in coords:ids.append(len(verts));verts.append((p[0],p[1],z))
  loops.append(ids)
 n=len(verts);verts += [(x,y,z+height) for x,y,z in verts];vectors=[[Vector(verts[i+n]) for i in loop] for loop in loops];lookup={tuple(Vector(verts[i+n])):i+n for loop in loops for i in loop};faces=[]
 for tri in tessellate_polygon(vectors):
  ids=[v+n if isinstance(v,int) else lookup[tuple(v)] for v in tri];faces.extend([ids,[i-n for i in reversed(ids)]])
 for loop in loops:
  for k,a in enumerate(loop):b=loop[(k+1)%len(loop)];faces.append([a,b,b+n,a+n])
 mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],faces);mesh.update();ob=bpy.data.objects.new(name,mesh);collections[col].objects.link(ob);mesh.materials.append(material);return ob
for r in R:
 ob=polygon_mesh(r['id'],r['geometry_model'],-.11,.12,roadmat,'URB_DRUMURI_STREET_LINE')
 for k in ['layer','area_m2','estimated_area_m2','status','source','thickness_m','base_m','top_m']:ob[k]=r[k]
colors={'Parcuri':(.13,.33,.23),'Scuaruri':(.20,.48,.33),'Fâșii plantate':(.34,.53,.28),'Spații verzi aferente locuințelor':(.39,.56,.48)}
for r in G:
 if r['id']=='SV-113':continue
 geo=json.loads(json.dumps(r['geometry']))
 for ring in geo['coordinates']:
  for p in ring:p[0]+=dx;p[1]+=dy
 polygon_mesh(r['id']+' / control V06',geo,.04,.035,mat(r['categorie'],colors[r['categorie']]),'VERDE_V06_CONTROL_SUPLIMENTAR')
# New PDF study border, visually independent from the road export.
for key,col in [('study',(.28,.39,.32)),('site',(.65,.29,.24))]:
 curve=bpy.data.curves.new('Limita_'+key,'CURVE');curve.dimensions='3D';curve.bevel_depth=.35;curve.bevel_resolution=0;ring=M[key]['coordinates'][0]
 for a,b in zip(ring,ring[1:]):
  aa=Vector(a);bb=Vector(b);length=(bb-aa).length
  for d in range(0,math.ceil(length),18):
   if length==0:continue
   p=aa+(bb-aa)*d/length;q=aa+(bb-aa)*min(d+11,length)/length;sp=curve.splines.new('POLY');sp.points.add(1);sp.points[0].co=(p.x+dx,p.y+dy,.17,1);sp.points[1].co=(q.x+dx,q.y+dy,.17,1)
 ob=bpy.data.objects.new('Limita_'+key,curve);collections['LIMITE_CONTROL'].objects.link(ob);curve.materials.append(mat('Limita_'+key,col))
bpy.ops.mesh.primitive_plane_add(size=12000,location=(0,0,-.13));bpy.context.object.name='Fundal_alb_control';bpy.context.object.data.materials.append(white)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=8;scene.cycles.max_bounces=0;scene.cycles.use_denoising=False;scene.render.threads_mode='FIXED';scene.render.threads=6;scene.world.use_nodes=True;scene.world.node_tree.nodes.get('Background').inputs['Color'].default_value=(1,1,1,1);scene.world.node_tree.nodes.get('Background').inputs['Strength'].default_value=1
angle=math.radians(26);elev=math.radians(42);c=math.cos(angle);s=math.sin(angle);coords=[(p[0]+dx,p[1]+dy) for p in M['study']['coordinates'][0]];uv=[(x*c+y*s,(-x*s+y*c)*math.sin(elev)) for x,y in coords];umin=min(p[0] for p in uv);umax=max(p[0] for p in uv);vmin=min(p[1] for p in uv);vmax=max(p[1] for p in uv);uc=(umin+umax)/2;vc=(vmin+vmax)/2;target=Vector((uc*c-vc/math.sin(elev)*s,uc*s+vc/math.sin(elev)*c,0));bpy.ops.object.camera_add();cam=bpy.context.object;cam.data.type='ORTHO';cam.location=target+Vector((s*math.cos(elev),-c*math.cos(elev),math.sin(elev)))*6000;cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.clip_end=20000;cam.data.ortho_scale=max(umax-umin,(vmax-vmin+100)*4400/2850)*1.1;scene.camera=cam
scene.render.resolution_x=4400;scene.render.resolution_y=2850;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG';scene.render.film_transparent=False;scene.view_settings.view_transform='Standard';scene.view_settings.look='None';scene.render.use_freestyle=True;fs=scene.view_layers[0].freestyle_settings
for ls in list(fs.linesets):fs.linesets.remove(ls)
ls=fs.linesets.new('Cladiri_control');ls.select_by_collection=True;ls.collection=collections['REFERENCE_IFC'];ls.collection_negation='INCLUSIVE';ls.select_silhouette=True;ls.select_border=True;ls.select_crease=True;ls.select_contour=True;ls.select_by_visibility=True;ls.visibility='VISIBLE';ls.linestyle.color=(.18,.21,.19);ls.linestyle.thickness=1.15
scene['Reference_IFC']='261019 Obor_Volumetrie_monumente.ifc';scene['Control_green']='Inventar V06, supliment pentru verificare, nu este inclus în IFC drumuri';scene['Road_layer']='URB_DRUMURI_STREET_LINE';scene.render.filepath='//Obor_Drumuri_V11_control_axon.png';bpy.ops.wm.save_as_mainfile(filepath=O+'/Obor_Drumuri_V11_control.blend');print('Saved control model',len(bpy.data.objects),'objects',flush=True);bpy.ops.render.render(write_still=True)
